# Roofing company website template

A complete, original roofing-contractor site on **TanStack Start** and a
**Cloudflare Worker**, wired to Whop for checkout, financing, pixel events,
member capture and invoicing. The sample brand is "Lucky Roofing Company".
Every business detail is in one file, so you can re-skin it in minutes.

| Route | What it is |
| --- | --- |
| `/` | Hero, services, service area, financing, reviews, estimate form, footer |
| `/book` | Pick a plan (inspection, deposit, gutter cleaning) and pay on-site |
| `/checkout/$planId` | Whop checkout for a single plan (from the storefront template) |
| `/order-complete` | Where Whop returns the buyer after paying |
| `/admin/final-invoice` | Demo: bill the remaining balance with the Whop Invoices API |
| `/policies/privacy`, `/policies/terms` | Template policy pages (replace the text) |

## Run it

```bash
bun install
bun run dev          # local dev server
bun run typecheck
bun run build
```

Publishing is done separately with `whop apps deploy`. Keep `whop.app.json`,
the Whop Vite plugin and the build layout as they are.

## Rebrand it: `src/config/site.ts`

Nothing business-specific lives outside this file (apart from the checkout
template's own settings, below). Edit `SITE`:

| Key | Controls |
| --- | --- |
| `name`, `shortName`, `logoLines`, `tagline`, `description`, `url` | Titles, header and footer logo, share text, canonical URLs |
| `phone`, `email`, `address`, `hours` | Header, mobile call bar, contact block, footer |
| `brand` | Navy, orange, paper and ink colors and the Google Fonts URL. They become CSS variables, and the wordmark used in checkout is generated from them. |
| `hero`, `trustBadges`, `services`, `serviceArea` | Home page copy and service cards |
| `financing` | Financing callout copy (see "Financing") |
| `reviews` | Testimonials. `isSample: true` shows a "sample" label. Set it to `false` once they are real. |
| `estimate` | Service options and success/error copy for the estimate form |
| `plans` | The three Whop plans: plan id, product id, display price, features |
| `whop.accountId` | The Whop business (`biz_…`) this site bills through |
| `invoicing` | Settings for the final-balance invoice |
| `checkout`, `policies`, `footerNote` | Checkout headings, post-purchase steps, policy text |

Also replace `public/og.png` (1200×630) with your own share image.

Before launch, replace the sample licence number, phone, email, address,
reviews and policy text. They are placeholders.

## Whop resources you need

1. **Three plans on products you own**, one-time, in USD. Put each `plan_…` /
   `prod_…` pair and its displayed price in `SITE.plans`. The shown price is
   for display only. The amount charged always comes from the plan in Whop.
   Keep them in sync.

   | Plan | Price | Plan id | Product id |
   | --- | --- | --- | --- |
   | Inspection | $149 | `plan_sd48OPzpcCuBm` | `prod_OWXLgRelXweNU` |
   | Project deposit | $500 | `plan_J60imbCur5ndC` | `prod_2udldkvTrVEpZ` |
   | Gutter cleaning | $225 | `plan_cs6S6LHIN9Wtl` | `prod_7jsKSm0LP20c4` |

2. **Buy-now-pay-later approval** on the Whop account, if you want Klarna,
   Affirm or Afterpay at checkout.
3. **Apple Pay / Google Pay**: the site's domain must be registered and
   approved for the account (Whop Domains API or dashboard).
4. **One app secret, `ADMIN_TOKEN`**, a long random string that guards
   `/admin/final-invoice`. Without it the page refuses every call.
5. The platform injects the company API key at the edge. If you run the SDK
   yourself, its key needs permissions along these lines (check the exact scope
   names in the Whop developer dashboard):
   - `member:basic:read`, `member:email:read` and member create/update: estimate form
   - `member:payment_methods:read` and `payment:charge`: auto-charging a saved card
   - `invoice:create` and `plan:create`: creating the invoice and its one-time price
   - `access_pass:create`: only if `invoicing.finalBalanceProductId` is empty, so
     Whop creates the hidden "final balance" product on first use

## How each Whop feature is wired

### Checkout (`/checkout/$planId`)

It uses the storefront template's checkout (`src/routes/checkout.$planId.tsx`,
`src/lib/checkout/*`, `src/components/checkout/*`) built on `@whop/elements` and
`@whop/elements-react`: a payment element, email and address elements, wallet
buttons for Apple Pay and Google Pay, and the required branding element. There is
no custom card form. The server loads the order from Whop, quotes tax, and charges
through Whop. Don't replace this with your own payment form.

- **Branding / policies:** `STORE` at the top of the checkout and order-complete
  routes reads from `SITE`.
- **Allowed countries** and other checkout behavior: `src/lib/checkout/settings.ts`
  (`shipCountries` is `["US"]` here).
- **Success page:** `/order-complete` asks Whop for the payment's real status. It
  does not trust a `status` query parameter, so it only shows success for a paid order.

### Card on file for the deposit

The deposit plan is listed in `SITE.plans.deposit` with `savesCard: true`.
`futureUsageFor()` in `src/lib/checkout/order.ts` then asks Whop to save the card
for off-session use (`setupFutureUsage: "off_session"`) at the first payment. The
checkout shows `cardOnFileNote` under "Payment" so the buyer is told before paying. To make another plan save the card, set
`savesCard: true` on it.

### Estimate form (`EstimateForm.tsx` → `src/lib/estimate.functions.ts`)

A `createServerFn` handler validates the input (and drops honeypot spam), then:

1. Calls `members.create({ email, name })` through the Whop SDK (`POST /api/v1/members`).
2. Treats "already exists" (409) as success and looks up the existing member.
3. Adds a **member note** with phone, address/ZIP, service and message. Whop members
   have no phone or address fields, so a note is the supported place. If the existing
   member can't be found (the lookup needs the `member:email:read` scope), the note is
   skipped but the request still succeeds, and the `lead` event still carries the phone.

The visitor sees "Thanks, we'll call you within 1 business day" on success. A generic
"try again or call us" message shows only on a real failure. Raw API errors are never shown.
There is no Leads API call anywhere.

### Final balance invoice (`/admin/final-invoice`)

Enter the customer's email, an amount and a description. Pick one mode:

- **Auto-charge card on file:** `members.create` finds the member, then
  `paymentMethods.list` returns their saved off-session card, then `invoices.create` drafts
  the invoice with that `payment_method_id`, and `invoices.issue` charges it at once.
- **Send invoice:** `invoices.create` with `recipient_emails` and a due date, then `invoices.send`
  emails a pay link.

The amount is created as an inline one-time price, so any balance works. The access
guard is the `ADMIN_TOKEN` secret, compared on the server in constant time. It is a demo
guard. For real use, put the page behind your own staff login.

### Pixel events

All are guarded: `window.whop?.track(...)`, through `src/lib/track.ts`. They do nothing if the
Whop pixel isn't on the page. The app does not install a pixel.

| Event | When | Payload |
| --- | --- | --- |
| `service_viewed` | A service card scrolls into view, is expanded or its button is clicked | `service_name`, `service_id`, `interaction` |
| `view_content` | A plan card scrolls into view on `/book` | `variant_id`, `product_id`, `value`, `currency` |
| `initiate_checkout` | A checkout page opens | `variant_id`, `product_id`, `value`, `currency` |
| `deposit_started` | The deposit checkout opens | Same as above plus `plan_name` |
| `estimate_requested` | Estimate form submitted | `email`, `phone` |
| `lead` | Same moment | `email`, `phone` |

Product displays carry `data-whop-product-id`, `data-whop-variant-id`,
`data-whop-price` and `data-whop-currency` for the pixel's own scraping.

**To verify events:** open the site with the pixel active and run this in the
browser console before interacting:

```js
const t = window.whop.track; window.whop.track = (...a) => { console.log("whop.track", ...a); return t.apply(window.whop, a); };
```

Then scroll to the services, open `/book`, open a checkout, and submit the form. You
should see the events above. Then confirm them in your Whop pixel/analytics view.

### Financing

The callout in `SITE.financing` explains that Klarna, Affirm and Afterpay appear at Whop
checkout automatically when the merchant is approved and the order and buyer qualify. The site
quotes **no rates, terms or monthly prices**, because those are decided by the providers at
checkout. Keep it that way.

### SDK versions

`@whop/sdk` is pinned to `~2.6.0` because the storefront checkout template is written against
it. The newer members and invoices endpoints need 2.8.x, which is installed under the alias
`whop-sdk-latest` and used only by `src/lib/whop-api.server.ts`, `estimate.functions.ts` and
`invoice.functions.ts`. When you next update the checkout template, you can move everything to
one version and drop the alias.

## Project layout

```
src/config/site.ts            all business config
src/routes/                   pages (index, book, checkout, order-complete, admin, policies)
src/components/site/          header, footer, forms, service cards, roof illustration
src/components/checkout/      checkout template UI
src/lib/estimate.functions.ts estimate → Whop member + note
src/lib/invoice.functions.ts  final-balance invoice server function
src/lib/track.ts              guarded pixel helper
src/lib/seo.ts                per-route title and share metadata
src/lib/checkout/             checkout template logic (pixel.ts and order.ts are lightly customized)
```

Every page route needs a unique `staticData.pageId` (`pg_` plus 12 characters). Copy an
existing route when adding one.
