import { useEffect, useRef, useState, type FormEvent } from "react";
import { SITE } from "../../config/site";
import { useEstimateDraft } from "../../lib/estimate-store";
import { submitEstimate } from "../../lib/estimate.functions";
import { track } from "../../lib/track";
import { ArrowIcon, CheckIcon } from "./Icons";

type Status = "idle" | "sending" | "done" | "error";

const COPY = SITE.estimate;

export function EstimateForm() {
	const draftService = useEstimateDraft((state) => state.service);
	const [service, setService] = useState("");
	const [status, setStatus] = useState<Status>("idle");
	const successRef = useRef<HTMLDivElement>(null);

	// A service card on the page pre-selects its service here.
	useEffect(() => {
		if (draftService) setService(draftService);
	}, [draftService]);

	useEffect(() => {
		if (status === "done") successRef.current?.focus();
	}, [status]);

	async function onSubmit(event: FormEvent<HTMLFormElement>) {
		event.preventDefault();
		if (status === "sending") return;
		const form = new FormData(event.currentTarget);
		const value = (key: string) => String(form.get(key) ?? "").trim();
		const input = {
			name: value("name"),
			email: value("email"),
			phone: value("phone"),
			address: value("address"),
			service: value("service"),
			message: value("message"),
			website: value("website"),
		};

		// Pixel: one event per submit. `lead` is the platform's lead-capture
		// convention; `estimate_requested` is this site's own.
		track("estimate_requested", { email: input.email, phone: input.phone });
		track("lead", { email: input.email, phone: input.phone });

		setStatus("sending");
		try {
			const result = await submitEstimate({ data: input });
			setStatus(result.ok ? "done" : "error");
		} catch {
			setStatus("error");
		}
	}

	if (status === "done") {
		return (
			<div
				ref={successRef}
				tabIndex={-1}
				role="status"
				className="border-l-8 border-orange bg-white p-8 outline-none"
			>
				<span className="inline-flex h-12 w-12 items-center justify-center bg-orange text-navy-deep">
					<CheckIcon width={26} height={26} />
				</span>
				<h3 className="display mt-5 text-4xl text-navy">{COPY.successTitle}</h3>
				<p className="mt-3 text-lg text-ink/80">{COPY.successBody}</p>
				<p className="mt-2 text-ink/70">
					Need us sooner? Call{" "}
					<a className="font-bold text-orange-ink underline" href={`tel:${SITE.phone.href}`}>
						{SITE.phone.display}
					</a>
					.
				</p>
			</div>
		);
	}

	const sending = status === "sending";

	return (
		<form onSubmit={onSubmit} className="relative bg-white p-6 shadow-[8px_8px_0_0_var(--brand-orange)] sm:p-8">
			<div className="grid gap-5 sm:grid-cols-2">
				<div>
					<label className="field-label" htmlFor="est-name">
						Your name
					</label>
					<input
						id="est-name"
						name="name"
						type="text"
						className="field"
						autoComplete="name"
						required
						minLength={2}
						maxLength={120}
						placeholder="Jane Doe"
					/>
				</div>
				<div>
					<label className="field-label" htmlFor="est-phone">
						Phone
					</label>
					<input
						id="est-phone"
						name="phone"
						type="tel"
						className="field"
						autoComplete="tel"
						inputMode="tel"
						required
						minLength={7}
						maxLength={40}
						placeholder="(555) 555-0123"
					/>
				</div>
				<div className="sm:col-span-2">
					<label className="field-label" htmlFor="est-email">
						Email
					</label>
					<input
						id="est-email"
						name="email"
						type="email"
						className="field"
						autoComplete="email"
						inputMode="email"
						required
						maxLength={254}
						placeholder="jane@example.com"
					/>
				</div>
				<div className="sm:col-span-2">
					<label className="field-label" htmlFor="est-address">
						Property address or ZIP
					</label>
					<input
						id="est-address"
						name="address"
						type="text"
						className="field"
						autoComplete="street-address"
						required
						minLength={3}
						maxLength={240}
						placeholder="123 Main St, Austin TX 78758"
					/>
				</div>
				<div className="sm:col-span-2">
					<label className="field-label" htmlFor="est-service">
						What do you need?
					</label>
					<select
						id="est-service"
						name="service"
						className="field"
						required
						value={service}
						onChange={(event) => setService(event.target.value)}
					>
						<option value="" disabled>
							Choose a service…
						</option>
						{COPY.serviceTypes.map((type) => (
							<option key={type} value={type}>
								{type}
							</option>
						))}
					</select>
				</div>
				<div className="sm:col-span-2">
					<label className="field-label" htmlFor="est-message">
						Anything we should know? <span className="font-sans normal-case tracking-normal text-ink/50">(optional)</span>
					</label>
					<textarea
						id="est-message"
						name="message"
						className="field min-h-28 resize-y"
						rows={4}
						maxLength={2000}
						placeholder="Active leak, storm damage, roof age, preferred timing…"
					/>
				</div>
			</div>

			{/* Honeypot: invisible to people, tempting to bots. */}
			<div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
				<label htmlFor="est-website">Leave this empty</label>
				<input id="est-website" name="website" type="text" tabIndex={-1} autoComplete="off" />
			</div>

			{status === "error" ? (
				<p role="alert" className="mt-5 border-l-4 border-red-600 bg-red-50 px-4 py-3 text-red-900">
					{COPY.errorMessage}{" "}
					<a className="font-bold underline" href={`tel:${SITE.phone.href}`}>
						{SITE.phone.display}
					</a>
				</p>
			) : null}

			<button type="submit" className="btn btn-orange mt-6 w-full" disabled={sending}>
				{sending ? "Sending…" : COPY.submitLabel}
				{sending ? null : <ArrowIcon width={22} height={22} />}
			</button>
			<p className="mt-3 text-center text-sm text-ink/60">{SITE.responsePromise} No obligation, no spam.</p>
		</form>
	);
}
