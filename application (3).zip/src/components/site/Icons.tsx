import type { SVGProps } from "react";
import type { ServiceIcon } from "../../config/site";

type IconProps = SVGProps<SVGSVGElement>;

const base = {
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "square" as const,
	strokeLinejoin: "miter" as const,
	"aria-hidden": true,
};

export function CheckIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M4 12.5 9.5 18 20 6.5" />
		</svg>
	);
}
export function PhoneIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M5 3h4l2 5-2.5 1.5a11 11 0 0 0 6 6L16 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2Z" strokeLinejoin="round" />
		</svg>
	);
}
export function MailIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<rect x="3" y="5" width="18" height="14" />
			<path d="m3 6 9 7 9-7" />
		</svg>
	);
}
export function PinIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21Z" strokeLinejoin="round" />
			<circle cx="12" cy="9.5" r="2.5" />
		</svg>
	);
}
export function ClockIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<circle cx="12" cy="12" r="9" />
			<path d="M12 7v5l3.5 2" />
		</svg>
	);
}
export function ArrowIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M4 12h15M13 6l6 6-6 6" />
		</svg>
	);
}
export function MenuIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M4 7h16M4 12h16M4 17h16" />
		</svg>
	);
}
export function CloseIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M5 5l14 14M19 5 5 19" />
		</svg>
	);
}
export function PlusIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M12 5v14M5 12h14" />
		</svg>
	);
}
export function StarIcon(props: IconProps) {
	return (
		<svg {...base} fill="currentColor" stroke="none" {...props}>
			<path d="m12 2.8 2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2 6.3 20.3l1.2-6.4L2.8 9.5l6.4-.8L12 2.8Z" />
		</svg>
	);
}
export function ShieldIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<path d="M12 3 4 6v6c0 4.5 3.2 8 8 9 4.8-1 8-4.5 8-9V6l-8-3Z" strokeLinejoin="round" />
			<path d="m8.5 12 2.5 2.5 4.5-5" />
		</svg>
	);
}
export function CardIcon(props: IconProps) {
	return (
		<svg {...base} {...props}>
			<rect x="3" y="5" width="18" height="14" />
			<path d="M3 10h18M7 15h4" />
		</svg>
	);
}

export function ServiceGlyph({
	icon,
	...props
}: IconProps & { icon: ServiceIcon }) {
	switch (icon) {
		case "repair":
			return (
				<svg {...base} width={32} height={32} {...props}>
					<path d="M14.5 6.5a4.5 4.5 0 0 0 5.2 5.9L11 21.1a2.1 2.1 0 0 1-3-3l8.6-8.7a4.5 4.5 0 0 1-2.1-3.9Z" strokeLinejoin="round" />
					<path d="m15 3 2.5 2.5L15 8" />
				</svg>
			);
		case "replace":
			return (
				<svg {...base} width={32} height={32} {...props}>
					<path d="M2 11 12 3l10 8" />
					<path d="M5 12.5 12 7l7 5.5M4 17l8-6.2 8 6.2M4 21l8-6.2 8 6.2" />
				</svg>
			);
		case "inspect":
			return (
				<svg {...base} width={32} height={32} {...props}>
					<circle cx="10.5" cy="10.5" r="6.5" />
					<path d="m15.5 15.5 6 6" />
					<path d="m7.5 11 2.2 2.2 3.8-4.4" />
				</svg>
			);
		case "gutter":
			return (
				<svg {...base} width={32} height={32} {...props}>
					<path d="M3 6h18v4H3zM7 10v7a3 3 0 0 0 3 3h1" />
					<path d="M16 13c1.2 1.6 1.8 2.6 1.8 3.5a1.8 1.8 0 0 1-3.6 0c0-.9.6-1.9 1.8-3.5Z" />
				</svg>
			);
		default:
			return (
				<svg {...base} width={32} height={32} {...props}>
					<path d="M7 16a4 4 0 0 1-.6-7.9A6 6 0 0 1 18 9a3.5 3.5 0 0 1 0 7H7Z" strokeLinejoin="round" />
					<path d="m12 14-2 4h3l-2 4" />
				</svg>
			);
	}
}
