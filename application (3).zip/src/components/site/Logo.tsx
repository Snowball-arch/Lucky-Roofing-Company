import { SITE } from "../../config/site";

export function LogoMark({ size = 44 }: { size?: number }) {
	return (
		<svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
			<rect width="48" height="48" fill="var(--brand-orange)" />
			<path d="M6 27 24 11l18 16" fill="none" stroke="var(--brand-navy-deep)" strokeWidth="5" strokeLinecap="square" />
			<path d="M13 28.5 24 19l11 9.5V39H13Z" fill="var(--brand-navy-deep)" />
			<rect x="21" y="30" width="6" height="9" fill="var(--brand-orange)" />
			<path d="M36 7l1.4 3.6L41 12l-3.600 1.400L36 17l-1.400-3.600L31 12l3.600-1.400Z" fill="var(--brand-navy-deep)" />
		</svg>
	);
}

export function Logo({ tone = "light" }: { tone?: "light" | "dark" }) {
	const [top, bottom] = SITE.logoLines;
	return (
		<span className="inline-flex items-center gap-3">
			<LogoMark />
			<span className="flex flex-col leading-none">
				<span
					className={`display text-[1.65rem] tracking-[0.04em] ${tone === "light" ? "text-white" : "text-navy"}`}
				>
					{top}
				</span>
				<span
					className={`eyebrow mt-1 text-[0.72rem] tracking-[0.32em] ${tone === "light" ? "text-orange" : "text-orange-ink"}`}
				>
					{bottom}
				</span>
			</span>
		</span>
	);
}
