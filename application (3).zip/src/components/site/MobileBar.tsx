import { Link } from "@tanstack/react-router";
import { SITE } from "../../config/site";
import { PhoneIcon } from "./Icons";

// A thumb-reach action bar on phones: call, or jump straight to the estimate form.
export function MobileBar() {
	return (
		<div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 gap-px border-t-2 border-orange bg-navy-deep md:hidden">
			<a
				href={`tel:${SITE.phone.href}`}
				className="display flex items-center justify-center gap-2 py-3.5 text-xl text-white"
			>
				<PhoneIcon width={20} height={20} /> Call
			</a>
			<Link
				to="/"
				hash="estimate"
				className="display flex items-center justify-center bg-orange py-3.5 text-xl text-navy-deep"
			>
				Free estimate
			</Link>
		</div>
	);
}
