// Decorative hero illustration: a gable roof with scalloped shingle courses.
// Pure SVG so it stays crisp, themeable via CSS variables and image-free.
export function RoofArt({ className = "" }: { className?: string }) {
	return (
		<svg
			className={className}
			viewBox="0 0 640 480"
			fill="none"
			role="img"
			aria-label="Illustration of a shingled roof"
		>
			<defs>
				<pattern id="shingle-a" width="44" height="26" patternUnits="userSpaceOnUse" patternTransform="translate(0 4)">
					<rect width="44" height="26" fill="var(--brand-slate)" />
					<path d="M0 13a22 13 0 0 0 44 0" stroke="var(--brand-navy-deep)" strokeWidth="2.5" fill="none" />
					<path d="M-22 26a22 13 0 0 0 44 0M22 26a22 13 0 0 0 44 0" stroke="var(--brand-navy-deep)" strokeWidth="2.5" fill="none" />
				</pattern>
				<linearGradient id="roof-shade" x1="0" y1="0" x2="0" y2="1">
					<stop offset="0" stopColor="#fff" stopOpacity="0.1" />
					<stop offset="1" stopColor="#000" stopOpacity="0.28" />
				</linearGradient>
			</defs>

			{/* Sun / lucky star */}
			<circle cx="520" cy="86" r="46" fill="var(--brand-orange)" opacity="0.95" />
			<circle cx="520" cy="86" r="62" stroke="var(--brand-orange)" strokeWidth="2" opacity="0.45" />

			{/* House body */}
			<rect x="118" y="292" width="404" height="170" fill="#e9e3d6" />
			<rect x="118" y="292" width="404" height="170" fill="url(#roof-shade)" opacity="0.5" />
			<rect x="170" y="338" width="74" height="84" fill="var(--brand-navy)" />
			<path d="M207 338v84M170 380h74" stroke="#e9e3d6" strokeWidth="4" />
			<rect x="396" y="338" width="74" height="124" fill="var(--brand-orange)" />
			<circle cx="455" cy="402" r="4" fill="var(--brand-navy-deep)" />
			<rect x="300" y="338" width="64" height="84" fill="var(--brand-navy)" />
			<path d="M332 338v84M300 380h64" stroke="#e9e3d6" strokeWidth="4" />

			{/* Chimney */}
			<rect x="400" y="96" width="52" height="118" fill="var(--brand-navy-deep)" />
			<rect x="392" y="88" width="68" height="16" fill="var(--brand-navy)" />

			{/* Roof */}
			<path d="M60 304 320 74l260 230Z" fill="url(#shingle-a)" />
			<path d="M60 304 320 74l260 230Z" fill="url(#roof-shade)" />
			<path d="M60 304 320 74l260 230" stroke="var(--brand-orange)" strokeWidth="10" strokeLinejoin="miter" strokeLinecap="square" />
			<path d="M44 312h552" stroke="var(--brand-navy-deep)" strokeWidth="14" strokeLinecap="square" />

			{/* Rain-cap sparkle */}
			<path d="m578 190 6 15 15 6-15 6-6 15-6-15-15-6 15-6Z" fill="var(--brand-orange)" />
			<path d="m84 160 4 10 10 4-10 4-4 10-4-10-10-4 10-4Z" fill="#fff" opacity="0.7" />

			{/* Ground */}
			<path d="M0 462h640" stroke="var(--brand-navy-deep)" strokeWidth="6" />
		</svg>
	);
}
