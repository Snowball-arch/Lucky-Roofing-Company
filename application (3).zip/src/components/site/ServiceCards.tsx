import { Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
	formatPrice,
	planByKey,
	SERVICES,
	SITE,
	type Service,
} from "../../config/site";
import { useEstimateDraft } from "../../lib/estimate-store";
import { track } from "../../lib/track";
import { ArrowIcon, CheckIcon, PhoneIcon, PlusIcon, ServiceGlyph } from "./Icons";

type Interaction = "view" | "expand" | "click";

function fireServiceViewed(service: Service, interaction: Interaction) {
	track("service_viewed", {
		service_name: service.name,
		service_id: service.id,
		interaction,
	});
}

function ServiceCard({ service, index }: { service: Service; index: number }) {
	const ref = useRef<HTMLElement>(null);
	const [open, setOpen] = useState(false);
	const setDraft = useEstimateDraft((state) => state.setService);
	const plan = service.planKey ? planByKey(service.planKey) : null;

	// Fires once, the first time at least 60% of the card is on screen.
	useEffect(() => {
		const node = ref.current;
		if (!node || typeof IntersectionObserver === "undefined") return;
		const observer = new IntersectionObserver(
			(entries) => {
				if (entries.some((entry) => entry.isIntersecting)) {
					fireServiceViewed(service, "view");
					observer.disconnect();
				}
			},
			{ threshold: 0.6 },
		);
		observer.observe(node);
		return () => observer.disconnect();
	}, [service]);

	return (
		<article
			ref={ref}
			id={`service-${service.id}`}
			className="group relative flex flex-col border-2 border-navy bg-white shadow-[6px_6px_0_0_var(--brand-navy)] transition-transform hover:-translate-y-1"
		>
			<span className="absolute -top-px left-0 h-2 w-full bg-orange" aria-hidden="true" />
			<div className="flex flex-1 flex-col p-6 pt-8 sm:p-7 sm:pt-9">
				<div className="flex items-start justify-between">
					<span className="inline-flex h-16 w-16 items-center justify-center bg-navy text-orange">
						<ServiceGlyph icon={service.icon} />
					</span>
					<span className="display text-6xl text-navy/10" aria-hidden="true">
						0{index + 1}
					</span>
				</div>
				<h3 className="display mt-5 text-4xl text-navy">{service.name}</h3>
				<p className="mt-3 text-lg leading-snug text-ink/80">{service.summary}</p>

				<button
					type="button"
					className="eyebrow mt-5 inline-flex w-fit items-center gap-2 text-orange-ink"
					aria-expanded={open}
					aria-controls={`service-details-${service.id}`}
					onClick={() => {
						const next = !open;
						setOpen(next);
						if (next) fireServiceViewed(service, "expand");
					}}
				>
					<PlusIcon
						width={18}
						height={18}
						className={`transition-transform ${open ? "rotate-45" : ""}`}
					/>
					What&rsquo;s included
				</button>

				<div id={`service-details-${service.id}`} hidden={!open} className="mt-4">
					<p className="text-ink/75">{service.details}</p>
					<ul className="mt-4 grid gap-2">
						{service.bullets.map((bullet) => (
							<li key={bullet} className="flex items-start gap-2.5">
								<CheckIcon width={20} height={20} className="mt-0.5 shrink-0 text-orange-ink" />
								<span>{bullet}</span>
							</li>
						))}
					</ul>
				</div>

				<p className="mt-auto pt-6 text-sm text-ink/60">{service.footnote}</p>

				<div className="mt-4 grid gap-3">
					<a
						href="#estimate"
						className="btn btn-navy"
						onClick={() => {
							setDraft(service.estimateType);
							fireServiceViewed(service, "click");
						}}
					>
						Free estimate <ArrowIcon width={20} height={20} />
					</a>
					{plan ? (
						<Link
							to="/checkout/$planId"
							params={{ planId: plan.planId }}
							className="btn btn-outline-navy"
							onClick={() => fireServiceViewed(service, "click")}
							data-whop-product-id={plan.productId}
							data-whop-variant-id={plan.planId}
							data-whop-price={plan.price}
							data-whop-currency={plan.currency}
						>
							{plan.shortName} · {formatPrice(plan.price)}
						</Link>
					) : (
						<a href={`tel:${SITE.phone.href}`} className="btn btn-outline-navy">
							<PhoneIcon width={20} height={20} /> Call {SITE.phone.display}
						</a>
					)}
				</div>
			</div>
		</article>
	);
}

export function ServiceCards() {
	return (
		<div className="grid gap-9 md:grid-cols-3">
			{SERVICES.map((service, index) => (
				<ServiceCard key={service.id} service={service} index={index} />
			))}
		</div>
	);
}
