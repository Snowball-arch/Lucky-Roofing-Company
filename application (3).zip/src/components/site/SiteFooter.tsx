import { Link } from "@tanstack/react-router";
import { SITE } from "../../config/site";
import { MailIcon, PhoneIcon, PinIcon } from "./Icons";
import { Logo } from "./Logo";

export function SiteFooter() {
	return (
		<footer className="relative bg-navy-deep pb-28 pt-16 text-white/75 md:pb-10">
			<div className="shingles pointer-events-none absolute inset-0" aria-hidden="true" />
			<div className="relative mx-auto grid max-w-7xl gap-12 px-6 md:grid-cols-[1.4fr_1fr_1fr]">
				<div>
					<Logo />
					<p className="mt-5 max-w-sm text-base leading-relaxed">{SITE.tagline}</p>
					<ul className="mt-6 flex flex-wrap gap-2">
						{SITE.trust.slice(0, 2).map((item) => (
							<li
								key={item.title}
								className="eyebrow border border-white/25 px-3 py-1 text-[0.75rem] text-white"
							>
								{item.title}
							</li>
						))}
					</ul>
				</div>

				<div>
					<h2 className="eyebrow text-orange">Explore</h2>
					<ul className="mt-4 grid gap-2.5">
						{SITE.nav.map((item) => (
							<li key={item.href}>
								<a href={item.href} className="hover:text-white">
									{item.label}
								</a>
							</li>
						))}
						<li>
							<Link to="/book" className="hover:text-white">
								Book &amp; pay online
							</Link>
						</li>
					</ul>
				</div>

				<div>
					<h2 className="eyebrow text-orange">Contact</h2>
					<ul className="mt-4 grid gap-3">
						<li className="flex items-start gap-3">
							<PhoneIcon width={18} height={18} className="mt-1 shrink-0 text-orange" />
							<a href={`tel:${SITE.phone.href}`} className="hover:text-white">
								{SITE.phone.display}
							</a>
						</li>
						<li className="flex items-start gap-3">
							<MailIcon width={18} height={18} className="mt-1 shrink-0 text-orange" />
							<a href={`mailto:${SITE.email}`} className="break-all hover:text-white">
								{SITE.email}
							</a>
						</li>
						<li className="flex items-start gap-3">
							<PinIcon width={18} height={18} className="mt-1 shrink-0 text-orange" />
							<span>{SITE.address}</span>
						</li>
					</ul>
				</div>
			</div>

			<div className="relative mx-auto mt-14 flex max-w-7xl flex-col gap-3 border-t border-white/10 px-6 pt-6 text-sm sm:flex-row sm:items-center sm:justify-between">
				<p>
					© {new Date().getFullYear()} {SITE.name}. All rights reserved.
				</p>
				<ul className="flex gap-5">
					<li>
						<Link to="/policies/$slug" params={{ slug: "privacy" }} className="hover:text-white">
							Privacy
						</Link>
					</li>
					<li>
						<Link to="/policies/$slug" params={{ slug: "terms" }} className="hover:text-white">
							Terms
						</Link>
					</li>
				</ul>
			</div>
			{SITE.footerNote ? (
				<p className="relative mx-auto mt-4 max-w-7xl px-6 text-xs text-white/45">{SITE.footerNote}</p>
			) : null}
		</footer>
	);
}
