import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { planByKey, SITE } from "../../config/site";
import { CloseIcon, MenuIcon, PhoneIcon } from "./Icons";
import { Logo } from "./Logo";

export function SiteHeader() {
	const [open, setOpen] = useState(false);
	const inspection = planByKey("inspection");

	return (
		<header className="sticky top-0 z-40 bg-navy text-white shadow-[0_2px_0_0_var(--brand-orange)]">
			<div className="hidden border-b border-white/10 bg-navy-deep md:block">
				<div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-1.5 text-sm text-white/75">
					<span>
						{SITE.trust[0].title} &amp; {SITE.trust[1].title.toLowerCase()} ·{" "}
						{SITE.serviceArea.cities[0].name}, {SITE.serviceArea.cities[0].state}
					</span>
					<a
						href={`tel:${SITE.phone.href}`}
						className="inline-flex items-center gap-2 font-semibold text-white hover:text-orange"
					>
						<PhoneIcon width={16} height={16} />
						{SITE.phone.display}
					</a>
				</div>
			</div>

			<div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
				<Link to="/" aria-label={`${SITE.name} — home`} onClick={() => setOpen(false)}>
					<Logo />
				</Link>

				<nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
					{SITE.nav.map((item) => (
						<a
							key={item.href}
							href={item.href}
							className="eyebrow text-[0.95rem] text-white/80 transition-colors hover:text-orange"
						>
							{item.label}
						</a>
					))}
				</nav>

				<div className="flex items-center gap-3">
					<Link
						to="/book"
						className="btn btn-orange hidden min-h-0 px-5 py-2.5 text-base sm:inline-flex"
					>
						Book inspection · ${inspection.price}
					</Link>
					<button
						type="button"
						className="inline-flex h-11 w-11 items-center justify-center border-2 border-white/40 lg:hidden"
						aria-expanded={open}
						aria-controls="mobile-menu"
						aria-label={open ? "Close menu" : "Open menu"}
						onClick={() => setOpen((value) => !value)}
					>
						{open ? <CloseIcon /> : <MenuIcon />}
					</button>
				</div>
			</div>

			{open ? (
				<nav
					id="mobile-menu"
					aria-label="Mobile"
					className="border-t border-white/10 bg-navy-deep px-4 pb-6 pt-2 lg:hidden"
				>
					<ul className="grid gap-1">
						{SITE.nav.map((item) => (
							<li key={item.href}>
								<a
									href={item.href}
									onClick={() => setOpen(false)}
									className="display block border-b border-white/10 py-3 text-2xl text-white"
								>
									{item.label}
								</a>
							</li>
						))}
					</ul>
					<div className="mt-5 grid gap-3">
						<Link to="/book" onClick={() => setOpen(false)} className="btn btn-orange">
							Book an inspection
						</Link>
						<a href={`tel:${SITE.phone.href}`} className="btn btn-ghost-light">
							<PhoneIcon width={20} height={20} /> {SITE.phone.display}
						</a>
					</div>
				</nav>
			) : null}
		</header>
	);
}
