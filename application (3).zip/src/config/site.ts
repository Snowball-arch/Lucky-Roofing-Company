/**
 * Lucky Roofing Company — the ONE file that holds the business.
 *
 * Rebranding this template for another roofer (or any local service business)
 * means editing this file and nothing else: name, phone, cities, services,
 * prices shown on the page, reviews, colours and the Whop plan IDs all live
 * here. Pages read from `SITE`; none of them hard-code a business fact.
 *
 * Everything marked SAMPLE is placeholder copy written so the template looks
 * finished. Replace it before you launch — especially licence numbers,
 * reviews and the phone number / email.
 */

export type ServiceIcon = "repair" | "replace" | "inspect" | "gutter" | "storm";

export type Service = {
	/** Stable id used in analytics (`service_viewed`) and as the card's anchor. */
	id: string;
	/** Name shown on the card and sent as `service_name` to the pixel. */
	name: string;
	icon: ServiceIcon;
	/** One line under the title. */
	summary: string;
	/** Revealed when the card is expanded. */
	details: string;
	bullets: string[];
	/** Small line at the foot of the card, e.g. what it usually involves. */
	footnote: string;
	/** Estimate-form option this card pre-selects. Must match `estimate.serviceTypes`. */
	estimateType: string;
	/** If set, the card also offers a pay-on-site button for this plan key (see `plans`). */
	planKey?: PlanKey;
};

export type PlanKey = "inspection" | "deposit" | "gutter";

export type Plan = {
	key: PlanKey;
	/** Whop plan (variant) id — the checkout prices and charges THIS plan. */
	planId: string;
	/** Whop product id the plan belongs to. */
	productId: string;
	name: string;
	/** Short label for lists and buttons. */
	shortName: string;
	/** Price in major units, for DISPLAY only. The charge always comes from the Whop plan. */
	price: number;
	currency: "USD";
	/** One-line pitch on /book. */
	blurb: string;
	/** What the buyer gets / what happens next. */
	includes: string[];
	/** Badge on the /book card, if any. */
	badge?: string;
	/** Save the buyer's card for later off-session charges (e.g. the final balance). */
	savesCard?: boolean;
	/** Extra pixel event fired when this plan's checkout opens (besides `initiate_checkout`). */
	startEvent?: string;
	/** Shown on the checkout under "Payment" when `savesCard` is on. */
	cardOnFileNote?: string;
};

export const SITE = {
	// ── Identity ────────────────────────────────────────────────────────────
	name: "Lucky Roofing Company",
	shortName: "Lucky Roofing",
	/** Two short lines for the logo lock-up. */
	logoLines: ["LUCKY", "ROOFING CO."] as const,
	tagline: "Roofs that outlast the weather. Crews that actually show up.",
	description:
		"Lucky Roofing Company repairs, replaces and inspects residential roofs across Central Texas. Licensed, insured, and honest about what your roof needs. Book an inspection or request a free estimate online.",
	/** Public origin, used for share cards and canonical URLs. */
	url: "https://lucky-roofing-company.whop.site",
	/** Share-card image (1200×630). Lives in /public. */
	ogImage: "/og.png",
	locale: "en_US",
	foundedYear: 2009, // SAMPLE

	// ── Contact ─────────────────────────────────────────────────────────────
	phone: { display: "(512) 555-0142", href: "+15125550142" }, // SAMPLE (555-01xx is reserved for fiction)
	email: "hello@luckyroofing.example", // SAMPLE
	address: "1200 Cedar Ridge Dr, Austin, TX 78758", // SAMPLE — shown in the footer/contact section
	hours: [
		{ days: "Mon – Fri", time: "7:00 am – 6:00 pm" },
		{ days: "Saturday", time: "8:00 am – 2:00 pm" },
		{ days: "Storm emergencies", time: "Call anytime" },
	],
	responsePromise: "We'll call you within 1 business day.",

	// ── Brand ───────────────────────────────────────────────────────────────
	brand: {
		navy: "#0E1B2C", // deep slate navy
		navyDeep: "#08111C",
		slate: "#1D3047",
		orange: "#FF6A13", // safety orange — fills, rules, highlights
		orangeInk: "#B84300", // orange dark enough for TEXT on light backgrounds
		paper: "#F4F1EA", // warm off-white section background
		ink: "#101A26",
		/** Google Fonts stylesheet for the display + body faces (also set in styles.css). */
		fontsHref:
			"https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800&family=Barlow:wght@400;500;600;700&display=swap",
	},

	// ── Navigation ──────────────────────────────────────────────────────────
	nav: [
		{ label: "Services", href: "/#services" },
		{ label: "Service area", href: "/#service-area" },
		{ label: "Financing", href: "/#financing" },
		{ label: "Reviews", href: "/#reviews" },
		{ label: "Contact", href: "/#contact" },
	],

	// ── Hero ────────────────────────────────────────────────────────────────
	hero: {
		eyebrow: "Residential roofing · Central Texas",
		/** One entry per line; the LAST line is set in the accent colour. */
		headline: ["Roofs built", "to outlast", "the weather."],
		subhead:
			"Leak repairs, full replacements and honest inspections from a licensed local crew. Know exactly what your roof needs before you spend a dollar on the wrong fix.",
		primaryCta: "Request an Estimate",
		secondaryCta: "Book an Inspection",
		stats: [
			{ value: "15+", label: "years on Central Texas roofs" }, // SAMPLE
			{ value: "3,200+", label: "roofs repaired or replaced" }, // SAMPLE
			{ value: "1 day", label: "typical estimate turnaround" },
		],
	},

	// ── Trust / licensing badges ────────────────────────────────────────────
	trust: [
		{ title: "Licensed", detail: "TX Roofing Contractor · Lic. # 000000" }, // SAMPLE — use your real licence
		{ title: "Fully insured", detail: "General liability + workers' comp" },
		{ title: "Written estimates", detail: "Itemized, no pressure, no surprises" },
		{ title: "Workmanship warranty", detail: "Backed in writing on every install" },
	],

	// ── Services (cards on the home page) ───────────────────────────────────
	services: [
		{
			id: "repair",
			name: "Roof Repair",
			icon: "repair",
			summary: "Leaks, missing shingles, flashing and storm damage — fixed once.",
			details:
				"We find the actual source of the leak (it is rarely where the stain is), repair it with matching materials and photograph the work so you can see what was done.",
			bullets: [
				"Leak tracing and sealing",
				"Shingle, flashing and vent repair",
				"Storm and hail damage assessment",
				"Photo report with every repair",
			],
			footnote: "Most repairs finish in a single visit.",
			estimateType: "Roof repair",
		},
		{
			id: "replacement",
			name: "Roof Replacement",
			icon: "replace",
			summary: "A complete tear-off and install, scheduled around your life.",
			details:
				"Full tear-off, decking inspection, underlayment and a manufacturer-rated shingle system, installed by our own crews and cleaned up every day.",
			bullets: [
				"Full tear-off and deck inspection",
				"Architectural and impact-rated shingles",
				"Ventilation and flashing done right",
				"Daily magnet sweep and cleanup",
			],
			footnote: "Reserve your install date with a project deposit.",
			estimateType: "Roof replacement",
			planKey: "deposit",
		},
		{
			id: "inspection",
			name: "Roof Inspection",
			icon: "inspect",
			summary: "A licensed inspector, a full photo report, a straight answer.",
			details:
				"Buying a home, after a storm, or just unsure of your roof's age? We walk the roof, document its condition and tell you plainly whether you need a repair, a replacement or nothing at all.",
			bullets: [
				"Full roof-surface and attic check",
				"Photo-documented written report",
				"Repair-vs-replace recommendation",
				"Useful for insurance and home sales",
			],
			footnote: "Flat inspection fee, paid online.",
			estimateType: "Roof inspection",
			planKey: "inspection",
		},
	] satisfies Service[] as Service[],

	// ── Service area ────────────────────────────────────────────────────────
	serviceArea: {
		eyebrow: "Where we work",
		headline: "Proudly roofing Central Texas.",
		body: "Our crews are based in Austin and work within roughly 50 miles. Not sure if you're in range? Ask — we'll tell you straight.",
		states: ["Texas"],
		cities: [
			{ name: "Austin", state: "TX" },
			{ name: "Round Rock", state: "TX" },
			{ name: "Cedar Park", state: "TX" },
			{ name: "Georgetown", state: "TX" },
			{ name: "Pflugerville", state: "TX" },
			{ name: "Leander", state: "TX" },
			{ name: "Kyle", state: "TX" },
			{ name: "San Marcos", state: "TX" },
			{ name: "Lakeway", state: "TX" },
			{ name: "Bee Cave", state: "TX" },
			{ name: "Dripping Springs", state: "TX" },
			{ name: "Buda", state: "TX" },
		],
		footnote: "Outside the list? Send your zip in the estimate form.",
	},

	// ── Financing callout ───────────────────────────────────────────────────
	// Copy only. Buy-now-pay-later options are NOT built into this site: they
	// appear inside Whop's checkout by themselves once the Whop account is
	// approved for them and the order is eligible. Never quote rates or terms.
	financing: {
		eyebrow: "Pay your way",
		headline: "Don't let the budget decide when your roof gets fixed.",
		body: "When our Whop checkout is approved for buy-now-pay-later, providers such as Klarna, Affirm and Afterpay appear automatically as payment options at checkout for eligible orders. You'll see exactly what is on offer before you pay.",
		providers: ["Klarna", "Affirm", "Afterpay"],
		points: [
			"Options show up inside the secure checkout — nothing extra to apply for here.",
			"Availability, approval and terms are decided by each provider at the moment you pay.",
			"Not every order or buyer qualifies, and amounts below a provider's minimum won't show it.",
		],
		steps: [
			"Pick your service and head to checkout.",
			"If pay-over-time is offered for your order, it appears beside card and wallet options.",
			"The provider confirms your approval and terms before you commit.",
		],
		cta: "See payment options at checkout",
		fineprint:
			"Financing options are provided by third parties and depend on your order, location and approval. Lucky Roofing Company does not set or guarantee rates, limits or terms. For a full replacement, ask us about your project's payment schedule.",
	},

	// ── Reviews ─────────────────────────────────────────────────────────────
	reviews: {
		eyebrow: "Neighbors say",
		headline: "Trust is earned one roof at a time.",
		/**
		 * While true, the section shows a small "sample reviews" label so
		 * placeholder testimonials are never passed off as real. Set to false
		 * once every entry below is a genuine, permissioned customer review.
		 */
		isSample: true,
		sourceNote: "Add your Google or Yelp profile link here",
		sourceHref: "",
		items: [
			{
				name: "Maria G.",
				place: "Round Rock, TX",
				service: "Roof replacement",
				rating: 5,
				quote:
					"They showed up when they said they would, covered the landscaping, and the yard was spotless every evening. Our new roof looks fantastic and the crew treated the house like their own.",
			},
			{
				name: "Daniel & Priya R.",
				place: "Cedar Park, TX",
				service: "Roof inspection",
				rating: 5,
				quote:
					"We booked the inspection before closing on our house. The report had photos of everything and a plain-English answer: two repairs, no replacement. Saved us from a very expensive guess.",
			},
			{
				name: "Tom H.",
				place: "Georgetown, TX",
				service: "Leak repair",
				rating: 5,
				quote:
					"Two other companies patched the same leak and it kept coming back. Lucky found the real source — a cracked vent boot — fixed it in one visit and sent photos. Dry ever since.",
			},
			{
				name: "Angela W.",
				place: "Austin, TX",
				service: "Gutter cleaning",
				rating: 5,
				quote:
					"Flat price up front, no upsell, and they hauled all the debris off the roof too. Easy to book online and the team was in and out in a morning.",
			},
		],
	},

	// ── Estimate form ("Request an Estimate") ───────────────────────────────
	estimate: {
		eyebrow: "Free estimate",
		headline: "Tell us about your roof.",
		body: "Takes about a minute. We'll call to confirm details and book a time to look at the roof — no obligation.",
		serviceTypes: [
			"Roof repair",
			"Roof replacement",
			"Roof inspection",
			"Gutter cleaning & debris removal",
			"Storm damage",
			"Not sure yet",
		],
		submitLabel: "Request my free estimate",
		successTitle: "Thanks — we've got it.",
		successBody: "Thanks, we'll call you within 1 business day.",
		errorMessage:
			"We couldn't send your request just now. Please try again in a moment, or call us.",
	},

	// ── Whop plans (already created on the Whop account) ────────────────────
	// Prices here are for display. The checkout prices and charges the Whop plan.
	plans: [
		{
			key: "inspection",
			planId: "plan_sd48OPzpcCuBm",
			productId: "prod_OWXLgRelXweNU",
			name: "Roof Inspection",
			shortName: "Inspection",
			price: 149,
			currency: "USD",
			blurb: "A licensed inspector, a full photo report and a plain-English recommendation.",
			includes: [
				"Roof surface, flashing and vent check",
				"Attic and decking look for moisture",
				"Photo-documented written report",
				"Repair-vs-replace recommendation",
			],
			badge: "Most booked",
		},
		{
			key: "deposit",
			planId: "plan_J60imbCur5ndC",
			productId: "prod_2udldkvTrVEpZ",
			name: "Project Deposit",
			shortName: "Deposit",
			price: 500,
			currency: "USD",
			blurb: "Reserve your install or repair date. Applied to your project total.",
			includes: [
				"Holds your spot on our crew schedule",
				"Applied toward your agreed project total",
				"Remaining balance is billed after the job is complete",
				"Your card is saved securely for that final balance",
			],
			savesCard: true,
			startEvent: "deposit_started",
			cardOnFileNote:
				"Your card is saved securely with Whop so Lucky Roofing can bill the remaining balance after the job is done. You'll see the exact consent below before you pay, and nothing else is charged without your agreement.",
		},
		{
			key: "gutter",
			planId: "plan_cs6S6LHIN9Wtl",
			productId: "prod_7jsKSm0LP20c4",
			name: "Gutter Cleaning & Roof Debris Removal",
			shortName: "Gutters & debris",
			price: 225,
			currency: "USD",
			blurb: "Flat-rate gutter cleaning plus debris cleared off the roof surface.",
			includes: [
				"Gutters and downspouts cleared and flushed",
				"Leaves and debris removed from the roof",
				"Flat rate — no upsell on the day",
				"Everything bagged and hauled away",
			],
		},
	] satisfies Plan[] as Plan[],

	/** The Whop account that sells the plans above and issues invoices. */
	whop: { accountId: "biz_sfEqTTAsQqnttV" },

	/** Final-balance invoices (see /admin/final-invoice). */
	invoicing: {
		/**
		 * Optional: an existing Whop product (prod_…) to hang the one-off "final
		 * balance" charge on. Leave empty to let Whop create a hidden product
		 * from `externalIdentifier` the first time (needs access_pass:create).
		 */
		finalBalanceProductId: "",
		externalIdentifier: "lucky-final-balance",
		productTitle: "Roof project — final balance",
		defaultDescription: "Final balance for your roofing project. Thank you for choosing Lucky Roofing Company.",
		/** Days from "send invoice" until it is due (manual-payment mode only). */
		dueInDays: 7,
	},

	// ── Contact section ─────────────────────────────────────────────────────
	contact: {
		eyebrow: "Get in touch",
		headline: "Talk to a roofer, not a call center.",
		body: "Call, email, or send the form. Storm damage or an active leak? Call — we pick up.",
	},

	// ── Checkout page copy ──────────────────────────────────────────────────
	checkout: {
		addressHeading: "Service address",
		/** Countries the address form accepts are set in src/lib/checkout/settings.ts. */
		supportEmail: "hello@luckyroofing.example", // SAMPLE
		nextSteps: [
			"A receipt is on its way to your inbox.",
			"We'll call you within 1 business day to confirm scheduling.",
			"Questions in the meantime? Call or email us — details below.",
		],
	},

	// ── Footer / legal ──────────────────────────────────────────────────────
	policies: {
		privacy: {
			title: "Privacy Policy",
			updated: "November 2026",
			body: [
				"This is template text. Replace it with your own policy before launch and have it reviewed by counsel.",
				"We collect the contact details you send us (name, email, phone, property address and project notes) so we can respond to your estimate request and schedule work.",
				"Payments are processed by Whop. Card details are entered into Whop's secure payment elements and never touch our servers. Whop's Buyer Terms of Service and Privacy Policy apply to payments.",
				"If you pay a project deposit, you may be asked to save your card with Whop so the remaining balance can be billed after the work is completed. You can ask us to stop using a saved card at any time.",
				"We don't sell your personal information. Contact us to access, correct or delete the details we hold about you.",
			],
		},
		terms: {
			title: "Terms of Service",
			updated: "November 2026",
			body: [
				"This is template text. Replace it with your own terms before launch and have it reviewed by counsel.",
				"Estimates are free and non-binding. Project pricing, scope and schedule are confirmed in a written agreement before work starts.",
				"Inspection fees are charged when booked. Project deposits reserve your place on our schedule and are applied toward your agreed project total; the remaining balance is billed after the job is complete.",
				"Refunds and cancellations: describe your own policy here (for example, how far ahead a deposit is refundable).",
				"All work is performed by licensed and insured crews. Warranty terms are provided in writing with your project agreement.",
			],
		},
	},
	footerNote:
		"Lucky Roofing Company is a sample business used to demonstrate this template.", // SAMPLE — delete or replace
} as const;

export type SiteConfig = typeof SITE;

// ── Derived helpers (no config below this line) ────────────────────────────

export const PLANS: readonly Plan[] = SITE.plans;
export const SERVICES: readonly Service[] = SITE.services;

export function planByKey(key: PlanKey): Plan {
	const plan = PLANS.find((entry) => entry.key === key);
	if (!plan) throw new Error(`site.ts: no plan with key "${key}"`);
	return plan;
}

export function planById(planId: string): Plan | undefined {
	return PLANS.find((entry) => entry.planId === planId);
}

/** Plan ids whose checkout should save the card for later off-session charges. */
export const CARD_ON_FILE_PLAN_IDS: readonly string[] = PLANS.filter(
	(plan) => plan.savesCard,
).map((plan) => plan.planId);

export function formatPrice(amount: number, currency = "USD"): string {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency,
		minimumFractionDigits: Number.isInteger(amount) ? 0 : 2,
	}).format(amount);
}

export function pageTitle(title?: string): string {
	return title ? `${title} | ${SITE.name}` : `${SITE.name} — Roof repair, replacement & inspection`;
}

export function absoluteUrl(path: string): string {
	if (/^https?:\/\//.test(path)) return path;
	return `${SITE.url}${path.startsWith("/") ? path : `/${path}`}`;
}
