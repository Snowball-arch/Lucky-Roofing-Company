import { SITE } from "../config/site";

// The checkout and order-complete pages show a wordmark image. Rather than ship
// a binary logo, build one from the config so rebranding stays in site.ts. Swap
// `WORDMARK_SRC` for a real logo URL whenever you have one.
function escapeXml(value: string): string {
	return value
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;");
}

export function wordmarkDataUri(): string {
	const [top, bottom] = SITE.logoLines;
	// An <img> SVG can't load web fonts, so pin each line's width: the lock-up
	// looks the same whichever fallback font the browser picks.
	const topWidth = Math.min(172, top.length * 26);
	const bottomWidth = Math.min(172, bottom.length * 15.5);
	const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280 90" width="280" height="90">
<path d="M6 52 L44 18 L82 52" fill="none" stroke="${SITE.brand.orange}" stroke-width="9" stroke-linecap="square" stroke-linejoin="miter"/>
<path d="M22 56 L44 36 L66 56 V72 H22 Z" fill="${SITE.brand.navy}"/>
<text x="98" y="48" font-family="Barlow Condensed, Arial Narrow, Arial, sans-serif" font-size="40" font-weight="800" textLength="${topWidth}" lengthAdjust="spacingAndGlyphs" fill="${SITE.brand.navy}">${escapeXml(top)}</text>
<text x="99" y="76" font-family="Barlow Condensed, Arial Narrow, Arial, sans-serif" font-size="25" font-weight="700" textLength="${bottomWidth}" lengthAdjust="spacingAndGlyphs" fill="${SITE.brand.orangeInk}">${escapeXml(bottom)}</text>
</svg>`;
	return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const WORDMARK_SRC = wordmarkDataUri();
