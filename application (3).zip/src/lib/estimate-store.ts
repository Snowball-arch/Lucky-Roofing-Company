import { create } from "zustand";

// Lets a service card pre-select its service in the estimate form further down
// the page, without putting anything in the URL.
type EstimateDraft = {
	service: string;
	setService: (service: string) => void;
};

export const useEstimateDraft = create<EstimateDraft>((set) => ({
	service: "",
	setService: (service) => set({ service }),
}));
