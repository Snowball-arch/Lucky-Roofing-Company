import { createServerFn } from "@tanstack/react-start";
// `whop-sdk-latest` is an npm alias for @whop/sdk >= 2.8 (see README): members.create
// and invoices.issue need it, while the storefront checkout template is typed for 2.6.
import { WhopError } from "whop-sdk-latest";
import { SITE } from "../config/site";
import { whopApi } from "./whop-api.server";

export type EstimateInput = {
	name: string;
	email: string;
	phone: string;
	address: string;
	service: string;
	message: string;
	/** Honeypot: real visitors never fill this. */
	website: string;
};

export type EstimateResult = { ok: true } | { ok: false };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function text(value: unknown, max: number): string {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}

// Throws on input the form can't have produced (the browser already checks the
// same rules, so a visitor only sees this when something is tampering).
function validateEstimate(input: unknown): EstimateInput {
	const raw = (typeof input === "object" && input !== null ? input : {}) as Record<
		string,
		unknown
	>;
	const value: EstimateInput = {
		name: text(raw.name, 120),
		email: text(raw.email, 254).toLowerCase(),
		phone: text(raw.phone, 40),
		address: text(raw.address, 240),
		service: text(raw.service, 80),
		message: text(raw.message, 2000),
		website: text(raw.website, 200),
	};
	if (value.name.length < 2) throw new Error("invalid name");
	if (!EMAIL.test(value.email)) throw new Error("invalid email");
	if (value.phone.replace(/\D/g, "").length < 7) throw new Error("invalid phone");
	if (value.address.length < 3) throw new Error("invalid address");
	if (!(SITE.estimate.serviceTypes as readonly string[]).includes(value.service)) {
		throw new Error("invalid service");
	}
	return value;
}

function statusOf(failure: unknown): number | undefined {
	return failure instanceof WhopError ? failure.statusCode : undefined;
}

// Whop answers "already a member" with 409, or a 422 whose message says so.
function isDuplicate(failure: unknown): boolean {
	const status = statusOf(failure);
	if (status === 409) return true;
	if (status !== 422 || !(failure instanceof WhopError)) return false;
	let body = "";
	try {
		body = JSON.stringify(failure.body ?? "") + failure.message;
	} catch {
		body = failure.message;
	}
	return /already|exist|duplicate|taken/i.test(body);
}

// What the visitor told us beyond name and email. Members have no phone or
// address fields the API lets us write, so it is kept as a note on the member,
// which the team sees in Whop.
function noteFor(input: EstimateInput): string {
	return [
		"Estimate request from the website",
		`Service: ${input.service}`,
		`Phone: ${input.phone}`,
		`Address / ZIP: ${input.address}`,
		input.message ? `Message: ${input.message}` : "Message: (none)",
		`Received: ${new Date().toISOString()}`,
	].join("\n");
}

// Best effort: finding an existing member by exact email needs the
// member:email:read scope, so this may return null and the note is skipped.
async function findMemberId(
	whop: ReturnType<typeof whopApi>,
	email: string,
): Promise<string | null> {
	try {
		const page = await whop.members.list({ query: email, first: 5 });
		const match = page.data.find((member) => member.email?.toLowerCase() === email);
		return match?.id ?? null;
	} catch {
		return null;
	}
}

/**
 * "Request an Estimate". Creates (or finds) the person as a Whop member with
 * POST /api/v1/members — the Leads API no longer exists — then attaches the
 * project details as a member note. An existing member is a success, and Whop's
 * own error text never reaches the visitor.
 */
export const submitEstimate = createServerFn({ method: "POST" })
	.validator(validateEstimate)
	.handler(async ({ data }): Promise<EstimateResult> => {
		if (data.website) return { ok: true }; // honeypot: look successful, do nothing

		const whop = whopApi();
		let memberId: string | null = null;
		try {
			const member = await whop.members.create({
				email: data.email,
				name: data.name,
			});
			memberId = member.id;
		} catch (failure) {
			// Already a member: not an error, the visitor just sees the success message.
			if (!isDuplicate(failure)) {
				console.error(
					"[estimate] member create failed",
					statusOf(failure) ?? "no status",
				);
				return { ok: false };
			}
			memberId = await findMemberId(whop, data.email);
		}

		if (memberId) {
			try {
				await whop.members.notes.create({
					member_id: memberId,
					content: noteFor(data),
				});
			} catch (failure) {
				// The member exists, which is what matters; the note is a bonus.
				console.error("[estimate] note failed", statusOf(failure) ?? "no status");
			}
		}
		return { ok: true };
	});
