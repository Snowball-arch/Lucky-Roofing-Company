import { createServerFn } from "@tanstack/react-start";
import { WhopError } from "whop-sdk-latest";
import { SITE } from "../config/site";
import { whopAccountId, whopApi } from "./whop-api.server";

export type InvoiceMode = "auto_charge" | "send_invoice";

export type FinalInvoiceInput = {
	token: string;
	email: string;
	amount: number;
	description: string;
	mode: InvoiceMode;
};

export type FinalInvoiceResult =
	| {
			ok: true;
			mode: InvoiceMode;
			steps: string[];
			member: { id: string; email: string };
			paymentMethod: { id: string; label: string } | null;
			invoice: {
				id: string;
				number: string;
				status: string;
				total: string;
				amountDue: string;
				checkoutLink: string | null;
				dueAt: string | null;
				recipientEmails: string[];
			};
	  }
	| {
			ok: false;
			code:
				| "not_configured"
				| "unauthorized"
				| "no_saved_method"
				| "whop_error";
			message: string;
	  };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateFinalInvoice(input: unknown): FinalInvoiceInput {
	const raw = (typeof input === "object" && input !== null ? input : {}) as Record<
		string,
		unknown
	>;
	const email = String(raw.email ?? "").trim().toLowerCase();
	const amount = Number(raw.amount);
	const description = String(raw.description ?? "").trim().slice(0, 500);
	const mode = raw.mode === "send_invoice" ? "send_invoice" : "auto_charge";
	if (!EMAIL.test(email)) throw new Error("Enter the customer's email.");
	if (!Number.isFinite(amount) || amount < 1 || amount > 250000) {
		throw new Error("Amount must be between $1 and $250,000.");
	}
	if (Math.round(amount * 100) / 100 !== amount) {
		throw new Error("Amount can have at most two decimals.");
	}
	return {
		token: String(raw.token ?? ""),
		email,
		amount,
		description: description || SITE.invoicing.defaultDescription,
		mode,
	};
}

// Constant-time string compare, so the token can't be guessed byte by byte.
function sameSecret(given: string, expected: string): boolean {
	const encoder = new TextEncoder();
	const a = encoder.encode(given);
	const b = encoder.encode(expected);
	let diff = a.length ^ b.length;
	for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
		diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
	}
	return diff === 0;
}

function describe(failure: unknown): string {
	if (failure instanceof WhopError) {
		const detail = failure.message?.slice(0, 300);
		return `Whop returned ${failure.statusCode ?? "an error"}${detail ? `: ${detail}` : ""}`;
	}
	return failure instanceof Error ? failure.message : "Unexpected error.";
}

/**
 * Bills the remaining balance after a job with the Whop Invoices API.
 *
 *  - "Auto-charge card on file": create a draft invoice with the member's saved
 *    `payment_method_id`, then ISSUE it. Issuing charges that saved method
 *    off-session straight away and sends no email.
 *  - "Send invoice for manual payment": create the draft with the customer as
 *    recipient (no payment method), then SEND it. Whop emails the invoice with
 *    a pay link and reminders after the due date.
 *
 * Guarded by the ADMIN_TOKEN secret: without it every call is refused.
 */
export const createFinalInvoice = createServerFn({ method: "POST" })
	.validator(validateFinalInvoice)
	.handler(async ({ data }): Promise<FinalInvoiceResult> => {
		const expected = process.env.ADMIN_TOKEN;
		if (!expected) {
			return {
				ok: false,
				code: "not_configured",
				message:
					"ADMIN_TOKEN is not set for this site, so invoicing is switched off. Add it as an app secret.",
			};
		}
		if (!data.token || !sameSecret(data.token, expected)) {
			await new Promise((resolve) => setTimeout(resolve, 500));
			return { ok: false, code: "unauthorized", message: "That admin token is not correct." };
		}

		const whop = whopApi(20);
		const accountId = whopAccountId();
		const steps: string[] = [];
		try {
			// Idempotent: returns the existing member unchanged when there is one.
			const member = await whop.members.create({ account_id: accountId, email: data.email });
			steps.push(`Found member ${member.id}`);

			let paymentMethod: { id: string; label: string } | null = null;
			if (data.mode === "auto_charge") {
				const methods = await whop.paymentMethods.list({
					member_id: member.id,
					future_usage: "off_session",
					first: 20,
				});
				const usable = methods.data.find(
					(method) =>
						!("card" in method) || !method.card.expired,
				);
				if (!usable) {
					return {
						ok: false,
						code: "no_saved_method",
						message:
							"This customer has no saved card for off-session charges. Ask them to pay the project deposit first, or choose “Send invoice for manual payment”.",
					};
				}
				const label =
					"card" in usable
						? `${usable.card.brand ?? "Card"} •••• ${usable.card.last4 ?? "????"}`
						: usable.payment_method_type;
				paymentMethod = { id: usable.id, label };
				steps.push(`Using saved payment method ${label}`);
			}

			const dueAt =
				data.mode === "send_invoice"
					? new Date(Date.now() + SITE.invoicing.dueInDays * 86_400_000).toISOString()
					: undefined;

			const draft = await whop.invoices.create({
				account_id: accountId,
				member_id: member.id,
				memo: data.description,
				metadata: { source: "lucky-final-balance", kind: "final_balance" },
				...(paymentMethod ? { payment_method_id: paymentMethod.id } : {}),
				...(data.mode === "send_invoice"
					? { recipient_emails: [data.email], due_at: dueAt }
					: {}),
				items: [
					{
						quantity: 1,
						description: data.description,
						variant: {
							currency: "usd",
							billing_type: "one_time",
							initial_price: data.amount,
							title: SITE.invoicing.productTitle,
							visibility: "hidden",
							...(SITE.invoicing.finalBalanceProductId
								? { product_id: SITE.invoicing.finalBalanceProductId }
								: {
										product: {
											external_identifier: SITE.invoicing.externalIdentifier,
											title: SITE.invoicing.productTitle,
										},
									}),
						},
					},
				],
			} as Parameters<typeof whop.invoices.create>[0]);
			steps.push(`Created draft invoice ${draft.id}`);

			const invoice =
				data.mode === "auto_charge"
					? await whop.invoices.issue({ id: draft.id })
					: await whop.invoices.send({ id: draft.id });
			steps.push(
				data.mode === "auto_charge"
					? "Issued invoice — Whop is charging the saved card (collection is asynchronous)"
					: "Sent invoice — Whop emailed the customer a payment link",
			);

			return {
				ok: true,
				mode: data.mode,
				steps,
				member: { id: member.id, email: data.email },
				paymentMethod,
				invoice: {
					id: invoice.id,
					number: invoice.number,
					status: invoice.status,
					total: `${invoice.total.amount} ${invoice.total.currency.toUpperCase()}`,
					amountDue: `${invoice.amount_due.amount} ${invoice.amount_due.currency.toUpperCase()}`,
					checkoutLink: invoice.checkout_link,
					dueAt: invoice.due_at,
					recipientEmails: invoice.recipient_emails,
				},
			};
		} catch (failure) {
			console.error(
				"[final-invoice] failed",
				failure instanceof WhopError ? failure.statusCode : "unknown",
			);
			return { ok: false, code: "whop_error", message: describe(failure) };
		}
	});
