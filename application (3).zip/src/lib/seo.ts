import { absoluteUrl, pageTitle, SITE } from "../config/site";

type SeoInput = {
	/** Page title without the site name; omit on the home page. */
	title?: string;
	description?: string;
	/** Path of this page, for the canonical and og:url. */
	path?: string;
	/** Absolute https URL or a path under the site origin. */
	image?: string;
	/** Keep a utility page out of search results. */
	noindex?: boolean;
};

// One place for every route's <title>, description and share-card tags.
export function seo({ title, description, path = "/", image, noindex }: SeoInput = {}) {
	const fullTitle = pageTitle(title);
	const text = description ?? SITE.description;
	const url = absoluteUrl(path);
	const picture = absoluteUrl(image ?? SITE.ogImage);
	return {
		meta: [
			{ title: fullTitle },
			{ name: "description", content: text },
			{ property: "og:type", content: "website" },
			{ property: "og:site_name", content: SITE.name },
			{ property: "og:locale", content: SITE.locale },
			{ property: "og:title", content: fullTitle },
			{ property: "og:description", content: text },
			{ property: "og:url", content: url },
			{ property: "og:image", content: picture },
			{ property: "og:image:width", content: "1200" },
			{ property: "og:image:height", content: "630" },
			{ property: "og:image:alt", content: `${SITE.name} — ${SITE.tagline}` },
			{ name: "twitter:card", content: "summary_large_image" },
			{ name: "twitter:title", content: fullTitle },
			{ name: "twitter:description", content: text },
			{ name: "twitter:image", content: picture },
			...(noindex ? [{ name: "robots", content: "noindex, nofollow" }] : []),
		],
		links: [{ rel: "canonical", href: url }],
	};
}
