// Thin, guarded wrapper over the Whop pixel that hosting injects. The preview
// (and any visitor who blocks it) has no `window.whop`, so every call is a
// no-op there and never throws.

type WhopPixel = { track?: (event: string, data?: Record<string, unknown>) => void };

declare global {
	interface Window {
		whop?: WhopPixel;
	}
}

export function track(event: string, data: Record<string, unknown> = {}): void {
	if (typeof window === "undefined") return;
	try {
		window.whop?.track?.(event, data);
	} catch {
		// Analytics must never break the page.
	}
}
