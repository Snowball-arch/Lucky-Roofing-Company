import { WhopClient } from "whop-sdk-latest";
import { SITE } from "../config/site";

// A client for this site's own server code (estimate form, final-balance
// invoices). The platform injects the company key at the network edge, so the
// token here is a placeholder, exactly as the whop_api guide describes. No
// `apiVersionDate` is pinned: the SDK sends the version it was generated for.
export function whopApi(timeoutInSeconds = 10): WhopClient {
	return new WhopClient({
		token: process.env.WHOP_API_KEY ?? "",
		baseUrl: `${process.env.WHOP_API_ORIGIN ?? "https://api.whop.com"}/api/v1`,
		timeoutInSeconds,
		maxRetries: 1,
	});
}

/** The Whop account (biz_…) this site sells for. */
export function whopAccountId(): string {
	return (
		process.env.WHOP_ACCOUNT_ID ??
		process.env.WHOP_COMPANY_ID ??
		SITE.whop.accountId
	);
}
