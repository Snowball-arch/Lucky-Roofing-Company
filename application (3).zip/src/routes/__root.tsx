import type { ReactNode } from "react";
import { useEffect } from "react";
import {
	createRootRoute,
	HeadContent,
	Outlet,
	Scripts,
	useRouterState,
} from "@tanstack/react-router";
import { MobileBar } from "../components/site/MobileBar";
import { SiteFooter } from "../components/site/SiteFooter";
import { SiteHeader } from "../components/site/SiteHeader";
import { SITE } from "../config/site";
import { useCartStore } from "../lib/cart";
import { ORDER_COMPLETE_PATH } from "../lib/checkout/shared";
// This file replaces the one the scaffold generated, which is where the global
// stylesheet was imported — without this line Tailwind and the reset never load.
import styles from "../styles.css?url";

// Brand colours come from src/config/site.ts. Only colour values are written
// here (no quotes or angle brackets), so nothing needs escaping.
const BRAND_VARS = `:root{--brand-navy:${SITE.brand.navy};--brand-navy-deep:${SITE.brand.navyDeep};--brand-slate:${SITE.brand.slate};--brand-orange:${SITE.brand.orange};--brand-orange-ink:${SITE.brand.orangeInk};--brand-paper:${SITE.brand.paper};--brand-ink:${SITE.brand.ink};}`;

function RootDocument({ children }: { children: ReactNode }) {
	return (
		<html lang="en" style={{ colorScheme: "light" }}>
			<head>
				<HeadContent />
				<style>{BRAND_VARS}</style>
			</head>
			{/* Scripts belongs inside body: as a sibling of body the browser moves
			    it on parse, and the relocated nodes no longer match hydration. */}
			<body>
				{children}
				<Scripts />
			</body>
		</html>
	);
}

function RootLayout() {
	useEffect(() => {
		// The checkout reads the saved cart when it settles an order.
		void useCartStore.persist.rehydrate();
	}, []);
	const pathname = useRouterState({
		select: (state) => state.location.pathname,
	});
	// Checkout and order confirmation draw their own header: site links there
	// would pull the buyer away mid-payment.
	const focused =
		pathname.startsWith("/checkout") ||
		pathname.startsWith(ORDER_COMPLETE_PATH);
	if (focused) return <Outlet />;

	return (
		<div className="flex min-h-screen flex-col">
			<SiteHeader />
			<main className="flex-1">
				<Outlet />
			</main>
			<SiteFooter />
			{pathname.startsWith("/admin") ? null : <MobileBar />}
		</div>
	);
}

export const Route = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{ name: "viewport", content: "width=device-width, initial-scale=1" },
			{ name: "color-scheme", content: "light" },
			{ name: "theme-color", content: SITE.brand.navy },
			{ title: SITE.name },
		],
		links: [
			{ rel: "preconnect", href: "https://fonts.googleapis.com" },
			{ rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
			{ rel: "stylesheet", href: SITE.brand.fontsHref },
			{ rel: "stylesheet", href: styles },
		],
	}),
	component: RootLayout,
	shellComponent: RootDocument,
});
