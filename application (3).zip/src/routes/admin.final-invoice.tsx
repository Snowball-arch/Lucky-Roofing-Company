import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { ArrowIcon, CardIcon, MailIcon, ShieldIcon } from "../components/site/Icons";
import { SITE } from "../config/site";
import {
	createFinalInvoice,
	type FinalInvoiceResult,
	type InvoiceMode,
} from "../lib/invoice.functions";
import { seo } from "../lib/seo";

export const Route = createFileRoute("/admin/final-invoice")({
	staticData: { pageId: "pg_hfvvKXMLgqL7" },
	head: () =>
		seo({
			title: "Final balance invoice (admin)",
			path: "/admin/final-invoice",
			description: "Internal tool: bill the remaining roofing balance with the Whop Invoices API.",
			noindex: true,
		}),
	component: FinalInvoicePage,
});

const MODES: { value: InvoiceMode; title: string; body: string; icon: typeof CardIcon }[] = [
	{
		value: "auto_charge",
		title: "Auto-charge card on file",
		body: "Uses the card the customer saved when they paid the project deposit. Whop charges it right away; no email is sent.",
		icon: CardIcon,
	},
	{
		value: "send_invoice",
		title: "Send invoice for manual payment",
		body: `Emails the customer an invoice with a pay link (due in ${SITE.invoicing.dueInDays} days). Whop sends reminders after the due date.`,
		icon: MailIcon,
	},
];

function FinalInvoicePage() {
	const [mode, setMode] = useState<InvoiceMode>("auto_charge");
	const [busy, setBusy] = useState(false);
	const [result, setResult] = useState<FinalInvoiceResult | null>(null);
	const [problem, setProblem] = useState<string | null>(null);

	async function onSubmit(event: FormEvent<HTMLFormElement>) {
		event.preventDefault();
		if (busy) return;
		const form = new FormData(event.currentTarget);
		setBusy(true);
		setResult(null);
		setProblem(null);
		try {
			const outcome = await createFinalInvoice({
				data: {
					token: String(form.get("token") ?? ""),
					email: String(form.get("email") ?? ""),
					amount: Number(form.get("amount")),
					description: String(form.get("description") ?? ""),
					mode,
				},
			});
			setResult(outcome);
		} catch (failure) {
			setProblem(failure instanceof Error ? failure.message : "Something went wrong.");
		} finally {
			setBusy(false);
		}
	}

	return (
		<section className="bg-paper py-14 md:py-20">
			<div className="mx-auto max-w-5xl px-5 sm:px-6">
				<p className="eyebrow flex items-center gap-3 text-orange-ink">
					<span className="h-1 w-10 bg-orange" aria-hidden="true" />
					Admin · demo guard
				</p>
				<h1 className="display mt-4 text-[clamp(2.8rem,7vw,5rem)] text-navy">Final balance invoice</h1>
				<p className="mt-5 max-w-3xl text-lg leading-relaxed text-ink/80">
					After the job is finished, bill what is left of the project. The deposit checkout saves the customer&rsquo;s
					card with Whop; this page then uses the Whop Invoices API to charge that saved card, or to email an
					invoice they can pay themselves.
				</p>

				<ol className="mt-8 grid gap-px border-2 border-navy bg-navy md:grid-cols-2">
					<li className="bg-white p-6">
						<h2 className="display text-2xl text-navy">Auto-charge card on file</h2>
						<ol className="mt-3 list-decimal space-y-1 pl-5 text-ink/80">
							<li>
								<code>members.create</code> finds the customer by email
							</li>
							<li>
								<code>paymentMethods.list</code> returns their saved off-session card
							</li>
							<li>
								<code>invoices.create</code> drafts the invoice with that <code>payment_method_id</code>
							</li>
							<li>
								<code>invoices.issue</code> opens it and charges the card immediately
							</li>
						</ol>
					</li>
					<li className="bg-white p-6">
						<h2 className="display text-2xl text-navy">Send invoice for manual payment</h2>
						<ol className="mt-3 list-decimal space-y-1 pl-5 text-ink/80">
							<li>
								<code>members.create</code> finds the customer by email
							</li>
							<li>
								<code>invoices.create</code> drafts it with <code>recipient_emails</code> and a due date
							</li>
							<li>
								<code>invoices.send</code> issues it and emails the pay link
							</li>
						</ol>
					</li>
				</ol>

				<form onSubmit={onSubmit} className="mt-10 bg-white p-6 shadow-[8px_8px_0_0_var(--brand-navy)] sm:p-9">
					<div className="grid gap-5 md:grid-cols-2">
						<div className="md:col-span-2">
							<label className="field-label" htmlFor="inv-token">
								Admin token
							</label>
							<input
								id="inv-token"
								name="token"
								type="password"
								className="field"
								autoComplete="off"
								required
								placeholder="The ADMIN_TOKEN secret"
							/>
							<p className="mt-1.5 flex items-center gap-2 text-sm text-ink/60">
								<ShieldIcon width={16} height={16} /> Checked on the server against the ADMIN_TOKEN app secret. It is
								never stored in the browser.
							</p>
						</div>
						<div>
							<label className="field-label" htmlFor="inv-email">
								Customer (member) email
							</label>
							<input
								id="inv-email"
								name="email"
								type="email"
								className="field"
								autoComplete="off"
								required
								placeholder="customer@example.com"
							/>
						</div>
						<div>
							<label className="field-label" htmlFor="inv-amount">
								Amount (USD)
							</label>
							<input
								id="inv-amount"
								name="amount"
								type="number"
								className="field"
								inputMode="decimal"
								min="1"
								max="250000"
								step="0.01"
								required
								placeholder="4200.00"
							/>
						</div>
						<div className="md:col-span-2">
							<label className="field-label" htmlFor="inv-description">
								Description (shown on the invoice)
							</label>
							<textarea
								id="inv-description"
								name="description"
								className="field min-h-24 resize-y"
								rows={3}
								maxLength={500}
								defaultValue={SITE.invoicing.defaultDescription}
							/>
						</div>
					</div>

					<fieldset className="mt-7">
						<legend className="field-label">How should it be collected?</legend>
						<div className="mt-2 grid gap-4 md:grid-cols-2">
							{MODES.map((option) => {
								const Icon = option.icon;
								const selected = mode === option.value;
								return (
									<label
										key={option.value}
										className={`flex cursor-pointer gap-4 border-2 p-4 transition-colors ${
											selected ? "border-orange bg-orange/10" : "border-navy/25 hover:border-navy"
										}`}
									>
										<input
											type="radio"
											name="mode"
											value={option.value}
											checked={selected}
											onChange={() => setMode(option.value)}
											className="mt-1.5 h-5 w-5 accent-[var(--brand-orange)]"
										/>
										<span>
											<span className="display flex items-center gap-2 text-2xl text-navy">
												<Icon width={22} height={22} /> {option.title}
											</span>
											<span className="mt-1 block text-sm leading-snug text-ink/70">{option.body}</span>
										</span>
									</label>
								);
							})}
						</div>
					</fieldset>

					<button type="submit" className="btn btn-orange mt-8 w-full sm:w-auto" disabled={busy}>
						{busy ? "Working…" : mode === "auto_charge" ? "Create invoice & charge card" : "Create & send invoice"}
						{busy ? null : <ArrowIcon width={22} height={22} />}
					</button>
				</form>

				<div aria-live="polite" className="mt-8">
					{problem ? (
						<p role="alert" className="border-l-4 border-red-600 bg-red-50 px-4 py-3 text-red-900">
							{problem}
						</p>
					) : null}
					{result ? <ResultPanel result={result} /> : null}
				</div>
			</div>
		</section>
	);
}

function ResultPanel({ result }: { result: FinalInvoiceResult }) {
	if (!result.ok) {
		return (
			<div role="alert" className="border-l-8 border-red-600 bg-white p-6">
				<h2 className="display text-3xl text-red-800">Not completed</h2>
				<p className="mt-2 text-lg text-ink/85">{result.message}</p>
				<p className="mt-2 text-sm text-ink/55">Code: {result.code}</p>
			</div>
		);
	}
	return (
		<div className="border-l-8 border-orange bg-white p-6">
			<h2 className="display text-3xl text-navy">
				{result.mode === "auto_charge" ? "Invoice issued — charging the card" : "Invoice sent"}
			</h2>
			<ul className="mt-3 list-disc space-y-1 pl-5 text-ink/80">
				{result.steps.map((step) => (
					<li key={step}>{step}</li>
				))}
			</ul>
			{result.invoice.checkoutLink ? (
				<p className="mt-4">
					Pay link:{" "}
					<a className="break-all font-bold text-orange-ink underline" href={result.invoice.checkoutLink}>
						{result.invoice.checkoutLink}
					</a>
				</p>
			) : null}
			<p className="eyebrow mt-6 text-ink/60">API result</p>
			<pre className="mt-2 overflow-x-auto bg-navy p-4 text-sm leading-relaxed text-white">
				{JSON.stringify(result, null, 2)}
			</pre>
		</div>
	);
}
