import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { ArrowIcon, CardIcon, CheckIcon, ShieldIcon } from "../components/site/Icons";
import { formatPrice, PLANS, SITE, type Plan } from "../config/site";
import { seo } from "../lib/seo";
import { track } from "../lib/track";

export const Route = createFileRoute("/book")({
	staticData: { pageId: "pg_WXmL4aLOYjuv" },
	head: () =>
		seo({
			title: "Book & pay online",
			path: "/book",
			description: `Book a roof inspection (${formatPrice(PLANS[0]?.price ?? 0)}), reserve your project date with a deposit, or order flat-rate gutter cleaning. Pay securely online with ${SITE.name}.`,
		}),
	component: BookPage,
});

function PlanCard({ plan }: { plan: Plan }) {
	const ref = useRef<HTMLElement>(null);

	// `view_content` once per product, when its card is first on screen.
	useEffect(() => {
		const node = ref.current;
		if (!node || typeof IntersectionObserver === "undefined") return;
		const observer = new IntersectionObserver(
			(entries) => {
				if (entries.some((entry) => entry.isIntersecting)) {
					track("view_content", {
						variant_id: plan.planId,
						product_id: plan.productId,
						value: plan.price,
						currency: plan.currency,
					});
					observer.disconnect();
				}
			},
			{ threshold: 0.5 },
		);
		observer.observe(node);
		return () => observer.disconnect();
	}, [plan]);

	return (
		<article
			ref={ref}
			id={plan.key}
			className="relative flex flex-col border-2 border-navy bg-white shadow-[6px_6px_0_0_var(--brand-navy)]"
			data-whop-product-id={plan.productId}
			data-whop-variant-id={plan.planId}
			data-whop-price={plan.price}
			data-whop-currency={plan.currency}
		>
			{plan.badge ? (
				<span className="eyebrow absolute -top-4 left-6 bg-orange px-3 py-1 text-[0.8rem] text-navy-deep">
					{plan.badge}
				</span>
			) : null}
			<div className="flex flex-1 flex-col p-7">
				<h2 className="display text-4xl text-navy">{plan.name}</h2>
				<p className="display mt-4 text-7xl text-navy">
					{formatPrice(plan.price)}
					<span className="ml-2 text-xl tracking-wide text-ink/55">
						{plan.savesCard ? "deposit" : "flat fee"}
					</span>
				</p>
				<p className="mt-4 text-lg leading-snug text-ink/80">{plan.blurb}</p>
				<ul className="mt-5 grid gap-2.5">
					{plan.includes.map((item) => (
						<li key={item} className="flex items-start gap-2.5">
							<CheckIcon width={20} height={20} className="mt-0.5 shrink-0 text-orange-ink" />
							<span>{item}</span>
						</li>
					))}
				</ul>
				<div className="mt-auto pt-8">
					<Link
						to="/checkout/$planId"
						params={{ planId: plan.planId }}
						className="btn btn-orange w-full"
					>
						Pay {formatPrice(plan.price)} securely <ArrowIcon width={22} height={22} />
					</Link>
				</div>
			</div>
		</article>
	);
}

function BookPage() {
	return (
		<>
			<section className="relative isolate overflow-hidden bg-navy pb-24 pt-14 text-white pitch-bottom md:pb-32 md:pt-20">
				<div className="shingles pointer-events-none absolute inset-0 -z-10" aria-hidden="true" />
				<div className="mx-auto max-w-7xl px-5 sm:px-6">
					<p className="eyebrow flex items-center gap-3 text-orange">
						<span className="h-1 w-10 bg-orange" aria-hidden="true" />
						Book &amp; pay online
					</p>
					<h1 className="display mt-4 text-[clamp(3rem,8vw,6rem)]">
						Pick it. <span className="text-orange">Pay it.</span> Done.
					</h1>
					<p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">
						Choose what you need and pay in under a minute with a card, Apple Pay or Google Pay. Prefer to talk
						first?{" "}
						<a href="/#estimate" className="font-bold text-orange underline">
							Request a free estimate
						</a>{" "}
						instead.
					</p>
				</div>
			</section>

			<section className="bg-paper pb-20 pt-4 md:pb-28">
				<div className="mx-auto max-w-7xl px-5 sm:px-6">
					<div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3">
						{PLANS.map((plan) => (
							<PlanCard key={plan.key} plan={plan} />
						))}
					</div>

					<ul className="mt-14 grid gap-px border-2 border-navy bg-navy md:grid-cols-3">
						<li className="flex items-start gap-4 bg-white p-6">
							<ShieldIcon width={28} height={28} className="shrink-0 text-orange-ink" />
							<span>
								<span className="display block text-2xl text-navy">Secure checkout</span>
								<span className="text-sm text-ink/70">
									Payments run on Whop. Card details never touch our site.
								</span>
							</span>
						</li>
						<li className="flex items-start gap-4 bg-white p-6">
							<CardIcon width={28} height={28} className="shrink-0 text-orange-ink" />
							<span>
								<span className="display block text-2xl text-navy">Pay your way</span>
								<span className="text-sm text-ink/70">
									Cards, Apple Pay and Google Pay. Buy-now-pay-later options such as Klarna, Affirm or Afterpay
									appear at checkout when available for your order.
								</span>
							</span>
						</li>
						<li className="flex items-start gap-4 bg-white p-6">
							<CheckIcon width={28} height={28} className="shrink-0 text-orange-ink" />
							<span>
								<span className="display block text-2xl text-navy">Confirmed in writing</span>
								<span className="text-sm text-ink/70">
									You&rsquo;ll get a receipt right away and a call within 1 business day to schedule.
								</span>
							</span>
						</li>
					</ul>
				</div>
			</section>
		</>
	);
}
