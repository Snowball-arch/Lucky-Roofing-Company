import { createFileRoute, Link } from "@tanstack/react-router";
import { EstimateForm } from "../components/site/EstimateForm";
import {
	ArrowIcon,
	CardIcon,
	CheckIcon,
	ClockIcon,
	MailIcon,
	PhoneIcon,
	PinIcon,
	ShieldIcon,
	StarIcon,
} from "../components/site/Icons";
import { RoofArt } from "../components/site/RoofArt";
import { ServiceCards } from "../components/site/ServiceCards";
import { formatPrice, planByKey, SITE } from "../config/site";
import { seo } from "../lib/seo";

export const Route = createFileRoute("/")({
	staticData: { pageId: "pg_k3Lw8RoofHm1" },
	head: () =>
		seo({
			path: "/",
			description: SITE.description,
		}),
	component: HomePage,
});

function SectionHeading(props: {
	eyebrow: string;
	title: string;
	body?: string;
	tone?: "light" | "dark";
	id?: string;
}) {
	const dark = props.tone === "dark";
	return (
		<div className="max-w-3xl">
			<p className={`eyebrow flex items-center gap-3 ${dark ? "text-orange" : "text-orange-ink"}`}>
				<span className="h-1 w-10 bg-orange" aria-hidden="true" />
				{props.eyebrow}
			</p>
			<h2
				id={props.id}
				className={`display mt-4 text-[clamp(2.6rem,6vw,4.6rem)] ${dark ? "text-white" : "text-navy"}`}
			>
				{props.title}
			</h2>
			{props.body ? (
				<p className={`mt-5 text-lg leading-relaxed ${dark ? "text-white/75" : "text-ink/75"}`}>{props.body}</p>
			) : null}
		</div>
	);
}

function Hero() {
	const inspection = planByKey("inspection");
	return (
		<section className="relative isolate overflow-hidden bg-navy pb-28 text-white pitch-bottom md:pb-40">
			<div className="shingles pointer-events-none absolute inset-0 -z-10" aria-hidden="true" />
			<div
				className="pointer-events-none absolute -right-32 -top-32 -z-10 h-[34rem] w-[34rem] rounded-full bg-steel/60 blur-3xl"
				aria-hidden="true"
			/>
			<div className="mx-auto grid max-w-7xl gap-14 px-5 pb-6 pt-12 sm:px-6 md:pt-20 lg:grid-cols-[1.1fr_1fr]">
				<div>
					<p className="eyebrow rise flex items-center gap-3 text-orange">
						<span className="h-1 w-10 bg-orange" aria-hidden="true" />
						{SITE.hero.eyebrow}
					</p>
					<h1 className="display rise rise-2 mt-5 text-[clamp(3.4rem,8.2vw,7rem)]">
						{SITE.hero.headline.map((line, index) => (
							<span
								key={line}
								className={`block ${index === SITE.hero.headline.length - 1 ? "text-orange" : ""}`}
							>
								{line}
							</span>
						))}
					</h1>
					<p className="rise rise-3 mt-7 max-w-xl text-lg leading-relaxed text-white/80 sm:text-xl">
						{SITE.hero.subhead}
					</p>
					<div className="rise rise-3 mt-9 flex flex-col gap-4 sm:flex-row">
						<a href="#estimate" className="btn btn-orange">
							{SITE.hero.primaryCta} <ArrowIcon width={22} height={22} />
						</a>
						<Link to="/book" className="btn btn-ghost-light">
							{SITE.hero.secondaryCta}
						</Link>
					</div>
					<ul className="rise rise-4 mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/80">
						{SITE.trust.slice(0, 3).map((item) => (
							<li key={item.title} className="flex items-center gap-2">
								<CheckIcon width={18} height={18} className="text-orange" />
								{item.title}
							</li>
						))}
					</ul>
					<dl className="rise rise-4 mt-12 grid max-w-xl grid-cols-3 gap-4 border-t border-white/15 pt-7">
						{SITE.hero.stats.map((stat) => (
							<div key={stat.label}>
								<dt className="display text-4xl text-white sm:text-5xl">{stat.value}</dt>
								<dd className="mt-1 text-sm leading-snug text-white/70">{stat.label}</dd>
							</div>
						))}
					</dl>
				</div>

				<div className="relative lg:min-h-[36rem]">
					<RoofArt className="rise rise-2 hidden lg:absolute lg:-right-10 lg:top-2 lg:block lg:w-[112%] lg:max-w-none" />
					<div
						className="rise rise-4 relative bg-paper p-6 text-navy shadow-[8px_8px_0_0_var(--brand-orange)] sm:p-7 lg:absolute lg:-bottom-10 lg:-left-8 lg:w-[22rem]"
						data-whop-product-id={inspection.productId}
						data-whop-variant-id={inspection.planId}
						data-whop-price={inspection.price}
						data-whop-currency={inspection.currency}
					>
						<p className="eyebrow text-orange-ink">Book online · pay securely</p>
						<div className="mt-2 flex items-end justify-between gap-4">
							<h2 className="display text-3xl">{inspection.name}</h2>
							<p className="display text-5xl text-navy">{formatPrice(inspection.price)}</p>
						</div>
						<ul className="mt-4 grid gap-2 text-[0.95rem]">
							{inspection.includes.slice(0, 3).map((item) => (
								<li key={item} className="flex items-start gap-2">
									<CheckIcon width={18} height={18} className="mt-0.5 shrink-0 text-orange-ink" />
									{item}
								</li>
							))}
						</ul>
						<Link
							to="/checkout/$planId"
							params={{ planId: inspection.planId }}
							className="btn btn-navy mt-5 w-full"
						>
							Book inspection
						</Link>
					</div>
				</div>
			</div>
		</section>
	);
}

function Services() {
	return (
		<section id="services" className="bg-paper py-20 md:py-28" aria-labelledby="services-title">
			<div className="mx-auto max-w-7xl px-5 sm:px-6">
				<SectionHeading
					id="services-title"
					eyebrow="What we do"
					title="Three ways we keep the rain out."
					body="Whether it is one stubborn leak or an entire roof at end of life, you get a clear scope, a written price and a crew that cleans up after itself."
				/>
				<div className="mt-14">
					<ServiceCards />
				</div>
			</div>
		</section>
	);
}

function ServiceArea() {
	const area = SITE.serviceArea;
	return (
		<section
			id="service-area"
			className="relative isolate overflow-hidden bg-navy py-20 text-white md:py-28"
			aria-labelledby="area-title"
		>
			<div className="shingles pointer-events-none absolute inset-0 -z-10" aria-hidden="true" />
			<div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-6 lg:grid-cols-[1.1fr_0.9fr]">
				<div>
					<SectionHeading id="area-title" tone="dark" eyebrow={area.eyebrow} title={area.headline} body={area.body} />
					<ul className="mt-9 flex flex-wrap gap-2.5">
						{area.cities.map((city) => (
							<li
								key={city.name}
								className="display flex items-center gap-2 border-2 border-white/25 px-4 py-2 text-xl text-white"
							>
								<PinIcon width={16} height={16} className="text-orange" />
								{city.name}, {city.state}
							</li>
						))}
					</ul>
					<p className="mt-6 text-white/65">{area.footnote}</p>
				</div>

				<div className="relative mx-auto aspect-square w-full max-w-md" aria-hidden="true">
					<svg viewBox="0 0 400 400" className="h-full w-full">
						<g fill="none" stroke="var(--brand-orange)">
							<circle cx="200" cy="200" r="190" strokeWidth="2" strokeDasharray="4 10" opacity="0.5" />
							<circle cx="200" cy="200" r="135" strokeWidth="2" opacity="0.4" />
							<circle cx="200" cy="200" r="80" strokeWidth="2" opacity="0.7" />
						</g>
						<g stroke="white" strokeOpacity="0.14">
							<path d="M200 10v380M10 200h380M65 65l270 270M335 65 65 335" />
						</g>
						<g fill="white" fillOpacity="0.9">
							{[
								[130, 120],
								[270, 150],
								[300, 260],
								[110, 290],
								[220, 70],
								[330, 200],
								[160, 340],
							].map(([x, y]) => (
								<rect key={`${x}-${y}`} x={x - 4} y={y - 4} width="8" height="8" />
							))}
						</g>
						<path d="M200 244s32-26 32-52a32 32 0 0 0-64 0c0 26 32 52 32 52Z" fill="var(--brand-orange)" />
						<circle cx="200" cy="192" r="12" fill="var(--brand-navy-deep)" />
					</svg>
					<p className="display absolute bottom-3 right-3 bg-orange px-3 py-1 text-xl text-navy-deep">
						~50 mi radius
					</p>
				</div>
			</div>
		</section>
	);
}

function Financing() {
	const financing = SITE.financing;
	return (
		<section id="financing" className="bg-white py-20 md:py-28" aria-labelledby="financing-title">
			<div className="mx-auto max-w-7xl px-5 sm:px-6">
				<div className="grid overflow-hidden border-2 border-navy lg:grid-cols-[1.2fr_1fr]">
					<div className="p-7 sm:p-12">
						<p className="eyebrow flex items-center gap-3 text-orange-ink">
							<span className="h-1 w-10 bg-orange" aria-hidden="true" />
							{financing.eyebrow}
						</p>
						<h2 id="financing-title" className="display mt-4 text-[clamp(2.4rem,5vw,4rem)] text-navy">
							{financing.headline}
						</h2>
						<p className="mt-5 text-lg leading-relaxed text-ink/80">{financing.body}</p>
						<ul className="mt-6 grid gap-3">
							{financing.points.map((point) => (
								<li key={point} className="flex items-start gap-3">
									<CheckIcon width={20} height={20} className="mt-1 shrink-0 text-orange-ink" />
									<span className="text-ink/80">{point}</span>
								</li>
							))}
						</ul>
						<Link to="/book" className="btn btn-orange mt-8 w-full sm:w-auto">
							{financing.cta} <ArrowIcon width={22} height={22} />
						</Link>
					</div>

					<div className="relative flex flex-col justify-between gap-9 bg-navy p-7 text-white sm:p-12">
						<div>
							<p className="eyebrow text-orange">May appear at checkout</p>
							<ul className="mt-5 grid gap-3">
								{financing.providers.map((provider) => (
									<li
										key={provider}
										className="display flex items-center justify-between border-2 border-white/25 px-5 py-3.5 text-3xl"
									>
										{provider}
										<CardIcon width={26} height={26} className="text-orange" />
									</li>
								))}
							</ul>
						</div>
						<ol className="grid gap-3">
							{financing.steps.map((step, index) => (
								<li key={step} className="flex gap-3 text-white/85">
									<span className="display flex h-8 w-8 shrink-0 items-center justify-center bg-orange text-xl text-navy-deep">
										{index + 1}
									</span>
									<span className="pt-0.5 leading-snug">{step}</span>
								</li>
							))}
						</ol>
						<p className="text-sm leading-relaxed text-white/60">{financing.fineprint}</p>
					</div>
				</div>
			</div>
		</section>
	);
}

function Stars({ count }: { count: number }) {
	return (
		<span className="inline-flex gap-0.5 text-orange" role="img" aria-label={`${count} out of 5 stars`}>
			{Array.from({ length: count }, (_, index) => (
				<StarIcon key={index} width={20} height={20} />
			))}
		</span>
	);
}

function Reviews() {
	const reviews = SITE.reviews;
	const average = reviews.items.reduce((sum, item) => sum + item.rating, 0) / Math.max(reviews.items.length, 1);
	return (
		<section id="reviews" className="bg-paper py-20 md:py-28" aria-labelledby="reviews-title">
			<div className="mx-auto max-w-7xl px-5 sm:px-6">
				<div className="flex flex-col justify-between gap-8 lg:flex-row lg:items-end">
					<SectionHeading id="reviews-title" eyebrow={reviews.eyebrow} title={reviews.headline} />
					<div className="flex items-center gap-5 border-2 border-navy bg-white px-6 py-4">
						<p className="display text-6xl text-navy">{average.toFixed(1)}</p>
						<div>
							<Stars count={Math.round(average)} />
							<p className="mt-1 text-sm text-ink/70">
								{reviews.items.length} reviews
								{reviews.isSample ? " · sample" : ""}
							</p>
						</div>
					</div>
				</div>

				{reviews.isSample ? (
					<p className="mt-6 inline-block border-l-4 border-orange bg-white px-4 py-2 text-sm text-ink/70">
						Sample reviews — replace with real customer reviews in <code>src/config/site.ts</code>.
					</p>
				) : null}

				<ul className="mt-10 grid gap-8 md:grid-cols-2">
					{reviews.items.map((review) => (
						<li key={review.name} className="relative border-2 border-navy bg-white p-7 pt-10">
							<span className="display absolute left-6 top-0 -translate-y-1/3 text-8xl leading-none text-orange" aria-hidden="true">
								&ldquo;
							</span>
							<Stars count={review.rating} />
							<blockquote className="mt-4 text-lg leading-relaxed text-ink/90">{review.quote}</blockquote>
							<p className="mt-5 flex flex-wrap items-baseline gap-x-3">
								<span className="display text-2xl text-navy">{review.name}</span>
								<span className="text-sm text-ink/65">
									{review.place} · {review.service}
								</span>
							</p>
						</li>
					))}
				</ul>
				{reviews.sourceHref ? (
					<a href={reviews.sourceHref} className="eyebrow mt-8 inline-flex items-center gap-2 text-orange-ink underline">
						Read more reviews <ArrowIcon width={18} height={18} />
					</a>
				) : null}

				<ul className="mt-14 grid gap-px border-2 border-navy bg-navy sm:grid-cols-2 lg:grid-cols-4">
					{SITE.trust.map((badge) => (
						<li key={badge.title} className="flex items-start gap-4 bg-white p-6">
							<span className="inline-flex h-12 w-12 shrink-0 items-center justify-center bg-navy text-orange">
								<ShieldIcon width={26} height={26} />
							</span>
							<span>
								<span className="display block text-2xl text-navy">{badge.title}</span>
								<span className="mt-1 block text-sm leading-snug text-ink/70">{badge.detail}</span>
							</span>
						</li>
					))}
				</ul>
			</div>
		</section>
	);
}

function Contact() {
	const contact = SITE.contact;
	return (
		<section
			id="contact"
			className="relative isolate overflow-hidden bg-navy py-20 text-white md:py-28"
			aria-labelledby="contact-title"
		>
			<div className="shingles pointer-events-none absolute inset-0 -z-10" aria-hidden="true" />
			<div className="mx-auto grid max-w-7xl gap-14 px-5 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
				<div>
					<SectionHeading id="contact-title" tone="dark" eyebrow={contact.eyebrow} title={contact.headline} body={contact.body} />
					<ul className="mt-10 grid gap-6">
						<li className="flex items-center gap-4">
							<span className="inline-flex h-14 w-14 shrink-0 items-center justify-center bg-orange text-navy-deep">
								<PhoneIcon width={26} height={26} />
							</span>
							<span>
								<span className="eyebrow block text-white/60">Call or text</span>
								<a href={`tel:${SITE.phone.href}`} className="display text-4xl hover:text-orange">
									{SITE.phone.display}
								</a>
							</span>
						</li>
						<li className="flex items-center gap-4">
							<span className="inline-flex h-14 w-14 shrink-0 items-center justify-center border-2 border-white/30 text-orange">
								<MailIcon width={26} height={26} />
							</span>
							<span className="min-w-0">
								<span className="eyebrow block text-white/60">Email</span>
								<a href={`mailto:${SITE.email}`} className="break-all text-xl font-semibold hover:text-orange">
									{SITE.email}
								</a>
							</span>
						</li>
						<li className="flex items-start gap-4">
							<span className="inline-flex h-14 w-14 shrink-0 items-center justify-center border-2 border-white/30 text-orange">
								<ClockIcon width={26} height={26} />
							</span>
							<span>
								<span className="eyebrow block text-white/60">Hours</span>
								<dl className="mt-1 grid gap-1 text-[0.95rem]">
									{SITE.hours.map((row) => (
										<div key={row.days} className="flex gap-3">
											<dt className="w-28 shrink-0 text-white/70 sm:w-40">{row.days}</dt>
											<dd className="font-semibold">{row.time}</dd>
										</div>
									))}
								</dl>
							</span>
						</li>
					</ul>
				</div>

				<div id="estimate" className="scroll-mt-24">
					<p className="eyebrow mb-1 text-orange">{SITE.estimate.eyebrow}</p>
					<h3 className="display mb-5 text-4xl text-white sm:text-5xl">{SITE.estimate.headline}</h3>
					<p className="mb-6 max-w-xl text-white/75">{SITE.estimate.body}</p>
					<EstimateForm />
				</div>
			</div>
		</section>
	);
}

function HomePage() {
	return (
		<>
			<Hero />
			<Services />
			<ServiceArea />
			<Financing />
			<Reviews />
			<Contact />
		</>
	);
}
