import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SITE } from "../config/site";
import { seo } from "../lib/seo";

type PolicySlug = keyof typeof SITE.policies;

function policyFor(slug: string) {
	return slug in SITE.policies ? SITE.policies[slug as PolicySlug] : null;
}

export const Route = createFileRoute("/policies/$slug")({
	staticData: { pageId: "pg_DxZo1H8VpkDN" },
	loader: ({ params }) => {
		const policy = policyFor(params.slug);
		if (!policy) throw notFound();
		return { title: policy.title };
	},
	head: ({ loaderData, params }) =>
		seo({
			title: loaderData?.title ?? "Policies",
			path: `/policies/${params.slug}`,
			description: `${loaderData?.title ?? "Policies"} for ${SITE.name}.`,
		}),
	component: PolicyPage,
	notFoundComponent: () => (
		<section className="mx-auto max-w-3xl px-6 py-24">
			<h1 className="display text-5xl text-navy">Page not found</h1>
			<p className="mt-4 text-lg">
				That page doesn&rsquo;t exist.{" "}
				<Link to="/" className="font-bold text-orange-ink underline">
					Back to home
				</Link>
			</p>
		</section>
	),
});

function PolicyPage() {
	const { slug } = Route.useParams();
	const policy = policyFor(slug);
	if (!policy) return null;
	return (
		<section className="bg-paper py-16 md:py-24">
			<article className="mx-auto max-w-3xl bg-white px-6 py-10 shadow-[8px_8px_0_0_var(--brand-navy)] sm:px-12">
				<p className="eyebrow text-orange-ink">{SITE.name}</p>
				<h1 className="display mt-3 text-5xl text-navy sm:text-6xl">{policy.title}</h1>
				<p className="mt-2 text-sm text-ink/60">Last updated {policy.updated}</p>
				<div className="mt-8 grid gap-5 text-lg leading-relaxed text-ink/85">
					{policy.body.map((paragraph) => (
						<p key={paragraph}>{paragraph}</p>
					))}
				</div>
				<p className="mt-10 text-ink/70">
					Questions? Email{" "}
					<a className="font-bold text-orange-ink underline" href={`mailto:${SITE.email}`}>
						{SITE.email}
					</a>{" "}
					or call{" "}
					<a className="font-bold text-orange-ink underline" href={`tel:${SITE.phone.href}`}>
						{SITE.phone.display}
					</a>
					.
				</p>
			</article>
		</section>
	);
}
